<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="libriLibreria.css" />
    <link rel="stylesheet" type="text/css" href="profiloLibreria.css" />
</head>
<body>
	<?php
		session_start();
		if(!(isset($_SESSION['email']))) {
			header('Location:login.php');
		}
		else { ?>
            <div id="contenitoreGrande" class="page_settings_profile">
                <!-- START HEADER -->
                <div id="dashboard">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
							$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email'])); /* Lo mettiamo un controllo su cosa restituisce?*/
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
                <div id="contenitorePiccolo">
                    <div id="content">
                        <div id="titolo_content">
                        	<?php
                        		$result=$client->addLibro(array('titolo'=>@$_POST['titolo'],'isbn'=>@$_POST['isbn'],
                        		'autore'=>@$_POST['autore'],'editore'=>@$_POST['editore'],'anno'=>@$_POST['anno'],
                        		'lingua'=>@$_POST['lingua'],'prezzo'=>@$_POST['prezzo'],'copie'=>@$_POST['copie'],
                        		'sconto'=>@$_POST['sconto'],'email'=>$_SESSION['email']));
										if((isset($_POST['titolo']))&&(isset($_POST['isbn']))&&(isset($_POST['autore']))
										 	&&(isset($_POST['editore']))&&(isset($_POST['anno']))&&(isset($_POST['lingua']))
										 		&&(isset($_POST['prezzo']))&&(isset($_POST['copie']))&&(isset($_POST['sconto']))) { 
											if($result->return==2) {
												echo 'Il libro è stato aggiunto soltanto alla tua libreria personale, in quanto già presente all interno del catalogo';	
											}
											else if($result->return==1) {
												echo 'Il libro è stato correttamente aggiunto al catalogo e alla libreria personale';
											}
											else {
												echo 'Si è verificato un problema. Per favore, riprova ad aggiungere il libro';
											}
										}
										else { ?>
		                            <h3>Aggiungi un libro al catalogo</h3>
		                            <h6>Qua potrai aggiungere i tuoi libri al catalogo centrale del sito e anche
		                            alla tua personale libreria</h6>
		                            <form id="change_profile" class="standard_form" action="addLibro.php" method="post">
		         	                    <h4>
		                                    <label for="titolo">
		                                        <span>Titolo</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci il titolo del libro</span>
		                                </h6>
		                                <div id="titolo_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="titolo" class="text_input" name="titolo" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <h4>
		                                    <label for="isbn">
		                                        <span>ISBN</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci l'ISBN del libro</span>
		                                </h6>
		                                <div id="isbn_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="isbn" class="text_input" name="isbn" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <h4>
		                                    <label for="autore">
		                                        <span>Autore</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci l'autore del libro</span>
		                                </h6>
		                                <div id="autore_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="autore" class="text_input" name="autore" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
												  <h4>
		                                    <label for="editore">
		                                        <span>Editore</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci l'editore del libro</span>
		                                </h6>
		                                <div id="editore_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="editore" class="text_input" name="editore" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <h4>
		                                    <label for="anno">
		                                        <span>Anno</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci l'anno di pubblicazione del libro</span>
		                                </h6>
		                                <div id="anno_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="anno" class="text_input" name="anno" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <h4>
		                                    <label for="lingua">
		                                        <span>Lingua</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci la lingua con cui è scritto il libro</span>
		                                </h6>
		                                <div id="lingua_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="lingua" class="text_input" name="lingua" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <h4>
		                                    <label for="prezzo">
		                                        <span>Prezzo</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci il prezzo di listino del libro</span>
		                                </h6>
		                                <div id="prezzo_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="prezzo" class="text_input" name="prezzo" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <h4>
		                                    <label for="copie">
		                                        <span>Numero copie</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci il numero di copie del libro che possiedi</span>
		                                </h6>
		                                <div id="copie_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="copie" class="text_input" name="copie" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <h4>
		                                    <label for="sconto">
		                                        <span>Sconto</span>
		                                    </label>
		                                </h4>
		                                <h6 class="instruction">
		                                    <span>Inserisci lo sconto che vuoi applicare su questo libro</span>
		                                </h6>
		                                <div id="sconto_div" class="input_wrap">
		                                    <?php
		                                        echo '<input type="text" id="sconto" class="text_input" name="sconto" size="30" maxlength="255" />';
		                                    ?>
		                                </div>
		                                <input type="submit" name="submit" value="Aggiungi il libro"/> 
		                            </form> <?php
		                      		}
		                      	?>
                        </div>                        
                    </div>
                </div>
                <!-- END CONTENUTO -->
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href=""> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href=""> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
            </div><?php
		}
	?>
</body>
</html>