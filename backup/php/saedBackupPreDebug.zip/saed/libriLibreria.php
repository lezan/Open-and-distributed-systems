<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="libriLibreria.css" />
</head>
<!-- Ci sono alcuni commenti all'interno del codice.
Tutto molto semplice e fa in sostanza la stessa cosa di recensioniUtente.php; qua stampa invece i libri di quella libreria.
Decidiamo se attivare i link del libro; se si bisogna fare le riche con il metodo get, così inseriamo direttamente il link
nei tag <a> del libro(facciamo una concatenazione tra 'parte-iniziale-default'.$result['titolo']. Il problema da risolvere 
sono gli spazi che ci possono essere nel nome. Dobbiamo trovare il modo di risolvere sto problema: eliminandoli o mettendoci delle 
'%'. 
IMPORTANTE: i bottoni modifica e cancella devono essere implementati ancora. -->
<body>
	<?php
		session_start();
		if(!(isset($_SESSION['email']))) {
			header('Location:login.php');
		}
		else {?>
            <div id="contenitoreGrande" class="page_settings_profile">
                <!-- START HEADER -->
                <div id="dashboard">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$client=SoapClient('http://localhost:8080/');
							$nomeLibreria=$client->leggiNomeLibreria($_SESSION['email']); /* Lo mettiamo un controllo su cosa restituisce?*/
                            echo '<strong>Ciao, '.$nomeLibreria.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
                <div id="contenitorePiccolo">
                    <div id="content">
                        <div id="titolo_content">
                            <h3>I miei libri</h3>
                            <h6>Qua sono visualizzate tutti i libri presenti nella mia lista</h6>
                        </div>
                        <?php
						  	$result=$client->ricercaLibreria($nomeLibreria);
							if($result[0][0]->return=='') {?>
                            	<div id="error_lista_libro"><?php
									echo 'Nessun libro da visualizzare';?>
                                </div><?php
							}
							else {
								?>
                                <table> 
									<?php
										foreach($result as $v1) {?>
											<tr>
												<td>
													<a id="cover_libro" href="#"><span>Cover</span></a>
												</td>
												<td>
													<ul>
                                                    	<!-- Il link lo possiamo mandare ad una pagina dove ci sono tutti i libri
                                                        con quel nome -->
														<li>
                                                        	<span>
																<?php
																	$link='/books/'.$v1['titolo'];
																	print '<a href="'.$link.'"><span>'.$v1['titolo'].'</span></a>'; 
																?>
                                                            </span>
                                                        </li>
                                                        <!-- Il link lo possiamo mandare ad una pagina dove ci sono tutti i libri
                                                        dell'autore -->
														<li><span><a href=""><?php echo $v1['autore']?></a></span></li>
                                                        <!-- Il link lo possiamo mandare ad una pagina dove ci sono tutti i libri
                                                        di quell'editore -->
														<li><span><?php echo $v1['editore']?></span></li>
                                                        <!-- Il link lo possiamo mandare alla pagina del libro -->
														<li>
                                                        	<span>
																<?php
																	$link='/books/'.$v1['titolo'];
																	print '<a href="'.$link.'"><span>'.$v1['titolo'].'</span></a>'; 
																?>
                                                            </span>
                                                        </li>
														<li><span>Prezzo: <?php echo $v1['prezzo']?> </span></li>
														<li><span>Lingua: <?php echo $v1['lingua']?></span></li>
														<li><span>Numero copie: <?php echo $v1['nCopie']?></span></li>
														<li><span>Sconto: <?php echo $v1['sconto']?></span></li>
													</ul>
												</td>
												<td id="bottoni">
                                                	<?php
														$linkMod='/modifica/libro/'.$v1['isbn'];
														print '<a href="'.$linkMod.'">Modifica</a>';
													?>
                                                    <br />
                                                    <?php
														$linkCanc="/cancella/libro/".$v1['isbn'];
														print '<a href="'.$linkCanc.'">Cancella</a>';
													?>
												</td>
											</tr><?php
										}
									?>
                        		</table>
                            <?php
							}
							?>
                        
                    </div>
                </div>
                <!-- END CONTENUTO -->
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href=""> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href="http://www.anobii.com/api_home"> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="http://www.anobii.com/contact" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
            </div><?php
		}
	?>
</body>
</html>