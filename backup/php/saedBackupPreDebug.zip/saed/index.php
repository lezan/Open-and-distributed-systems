<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="index.css" />
</head>
<!-- Dobbiamo controllare una cosa. L'utente si logga con username e password, mentre la libreria con email e password.
Quindi controllare che sia settata $_SESSION['username'] non mi pare sufficiente, ma bisogna anche controllare
$_SESSION['email'] per vedere se la libreria è loggata. 
Così forse può andare bene per capire se è libreria o utente.
Che ne dici? -->
<body>
	<?php 
		session_start();
	?>
    <div id="contenitore">
        <!-- START HEADER --><?php
        if(isset($_SESSION['username']) || isset($_SESSION['email'])) {
            if(isset($_SESSION['username'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
                            $username=$_SESSION['username'];
                            echo '<strong>Ciao, '.$username.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="/home" title="Logo | Home">Logo</a></span> 
                    </div>
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="recensioniUtente.php"><span>La mia recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                </div><?php
            }
            else if(isset($_SESSION['email'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$client=SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
							$nomeLibreria=$client->leggiNomeLibreria($_SESSION['email']);
                            echo '<strong>Ciao, '.$nomeLibreria.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                </div>
        <?php
            }
        }
        else {?>
            <div id="header">
                <div id="header_logo">
                    <a href="">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                </div>
                <div id="login">
                    <div id="botton_login">
                        <a href="login.php">Login</a>
                        |
                        <a href="iscrizioneUser.php">Iscriviti</a>
                        |
                        <a href="iscrizioneLibreria.php">Libreria</a>
                    </div>
                </div>
                <div id="scritta">
                    <h3 id="slogan">Anarchia.</h3>
                </div>
            </div><?php
        }?>
        <!-- END HEADER -->
        <!-- START TOP -->
        <div id="top">
            <div id="top_libreria"> Cerca </div>
            <div id="top_find"> Acquista </div>
            <div id="top_share"> Condividi </div>
            <div id="top_destro">
                <div class="top_destro_contenitore">
                    <h3 class="top_destro_titolo"> Cerca </h3>
                    <span class="top_destro_contentuto"> Cerca il libro che ti interessa </span>
                </div>
                <div class="top_destro_contenitore"> 
                    <h3 class="top_destro_titolo"> Acquista </h3>
                    <span class="top_destro_contentuto"> Acquistalo da uno dei nostri venditori </span>
                </div>
                <div class="top_destro_contenitore">
                    <h3 class="top_destro_titolo"> Condividi </h3>
                    <span class="top_destro_contentuto"> Valuta e recensisci i libri che hai acquistato e letto </span>
                </div>
            </div>
        </div>
        <!-- END TOP -->
        <!-- START CERCA -->
        <div id="cerca">
            <form action="cerca.php" method="post" >
                <input type="text" id="cerca_input" value="Cerca il tuo libro" />
                <input type="submit" id="cerca_bottone" value="Cerca"  />
            </form>
        </div>
        <!-- END CERCA -->
        <!-- START CONTENUTO -->
        <div id="contenuto">
            <div id="contenuto_sinistra" class="colonne">
                <h2 id="titolo_contenuto_sinistra">Aggiunti di recente</h2>
                <!-- Qua ci mettiamo una lista degli ultimi libri aggiunti al catalogo -->
                
                    <!--
                    Forse dobbiamo introdurre un campo nella tabella che tenga informazioni sulla data di introduzione
                    del libro, sia giorno che ora.
                    Aggiungere anche la funzione che si occupa di costruire una matrice che contenga le informazioni per
                    mostrare le novità, ovvero:
                    [titolo][autore][data*]
                    ...
                    [titolo][autore][data*]
                    Deve restituire questa matrice.
                    In input non prenden nulla.
                    -->
               	<?php 
					$client = new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
					$result=array(array());
					$result=$client->listaNovita();
					var_export($result->result);
					//if($result[0][0]=='') { //Qualcosa non è andato a buon fine nella funzione 
						/*
						Forse dovremmo creare una pagina in cui mandare l'utente quando si verificano questi errori.
						*/
						echo 'Non mi sento bene';
					//}
					//else {?>
						<ul class="liste"> <?php 
							for($i=0;$i<4;$i++) { ?>
								<li>								
									<div class="celle_contenuto>
										<?php
											$link="/books/".$result[i][0];
											print '<a href="'.$link.'"><span>'.$result[i][0].'</span></a>';
										?>
										di, <?php
											print '<a href="'.$result[i][1].'"><span>'.$result[i][1].'</span></a>';
										?>
										: <?php
											$result[i][2]
										?>
									</div>
								</li> <?php 
							} ?>
						</ul> <?php 
					//} 
				?>                
            </div>
            <div id="contenuto_centro" class="colonne">
                <h2>Recensioni recenti</h2>
                <!-- Qua ci mettiamo le ultime recensione scritte -->
                
                <!--
                Dobbiamo creare una funzione in java che si occupa di trovare le ultime recensioni sottoscritte.
                La funzione non riceve nulla in input.
                La funzione restituisce una matrice così composta:
                [autoreRecensioni][titoloLibro][autoreLibro]
                ...
                [autoreRecensioni][titoloLibro][autoreLibro]
                -->
				<?php
                    $client=new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
                    $result2=array();
                    $result2=$client->ultimeRecensioni();
                    if($result[0][0]->return=='') { //Qualcosa non è andato a buon fine nella funzione
                        echo 'Non mi sento bene';
                    }
                    else {?>
                        <ul class="liste"><?php 
							for($i=0;$i<4;$i++) {?>
                               	<li>								
                               		<div class="celle_contenuto>
                               			<a href=""><?php $result2[i][0]?></a> 
                                        ha recensito
                                        <?php
                                        	$link2='/books/'.$result2[i][1];
                                            print '<a href="'.$link2.'"><span>'.$result2[i][1].'</span></a>';
										?>
                                        , di 
                                        <?php
											print '<a href="'.$result2[i][2].'"><span>'.$result2[i][2].'</span></a>';
										?>
                               		</div>
                               	</li><?php 
							} ?>
                        </ul><?php 
					} 
				?>                
            </div>
            <div id="contenuto_destra" class="colonne">
                <h2>I libri più votati</h2>
                <!-- Qua possiamo metterci i libri con il punteggio più alto -->
                
                <?php 
					$client = new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
                    $result=array();
                    /*Implementare la funzione mostraVoti, che lista tutti i libri in ordine di voto decrescente.
                    Dovrà restituire una matrice contenente il titolo del libro, l autore e il voto.
                    [titolo][autore][voto*]
                    [titolo][autore][voto*]
                    ...
                    [titolo][autore][voto*]
                    In input non dovrà ricevere nulla.*/
                    $result3=$client->mostraVoti();
                    if($result3[0][0]->return==-1) {//Qualcosa non è andato a buon fine nella funzione
                        echo 'Non mi sento bene';
                    }
                    else { ?>
                        <ul class="liste"> <?php 
							for($i=0;$i<4;$i++) { ?>
                                <li>						
                                    <div class="celle_contenuto">
                                    	<?php
                                        	$link3="/books/".$result3[i][0];
                                            print '<a href="'.$link3.'"><span>'.$result3[i][0].'</span></a>';
										?>
                                        , di
                                        <?php
											print '<a href="'.'"><span>'.$result3[i][1].'</span></a>';
										?>
                                        : 
										<?php $result3[i][2]?>;
                                    </div>
                                </li> <?php 
							} ?>
                        </ul> <?php 
					} 
				?>                
            </div>
        </div>
        <!-- END CONTENUTO -->
        <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href=""> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href="http://www.anobii.com/api_home"> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="http://www.anobii.com/contact" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
        <!-- END FOOTER -->
    </div>
</body>
</html>
