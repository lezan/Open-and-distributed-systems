<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="libriLibreria.css" />
</head>
<body>
	<?php
		session_start();
		function getUrl() {
 			return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
		}
		if(!(isset($_SESSION['email']))) {
			header('Location:login.php');
		}
		$client=SoapClient('http://localhost:8080/');
		if ($action=="modifica"){
			$result2=$client->modificaRecensione($_SESSION['username'],$_POST['ISBN'],$_POST['testo']);
			if ($result2!=1){ /* Insuccesso della funzione */
				/*usando l'array post qui, evitiamo altre chiamate soap per leggere di nuovo i dati, nel caso di errori*/
				echo 'Recensione del libro: '.$result['0'].'<br/>';
				echo '<form name="modificaRecensione" action="modificaRecensione.php" method="POST">';
				echo '<input type="text" name ="testo" value="'.$_POST['testo'].'/><br/>';
				echo '<input type="hidden" name="ISBN" value="'.$_POST['ISBN'].'"/>';
				echo '<input type="hidden" name="action" value="modifica"/>';
				echo '<input type="submit" value="Invia"/><br>';
				echo '<a href="recensioniUtente.php">Torna alle recensioni!</a>';
				echo '</form>';
			}
			else { /* Successo della modifica quando ==1*/
				header("Location:recensioniUtente.php");
			}
		}
		else {
			$ISBN=getUrl();
			$result=$client->leggiRecensione($_SESSION['username'],$ISBN);
			echo 'Recensione del libro: '.$result[0].'<br/>';
			echo '<form name="modificaRecensione" action="modificaRecensione.php" method="POST">';
			echo '<input type="text" name ="testo" value="'.$result[1].'/><br/>';
			echo '<input type="hidden" name="action" value="modifica"/>';
			echo '<input type="hidden" name="ISBN" value="'.$ISBN.'"/>';
			echo '<input type="submit" value="Invia"/><br/>';
			echo '<a href="recensioniUtente.php">Torna alle recensioni!</a>';
			echo '</form>';
		}
	?>
</body>
</html>
