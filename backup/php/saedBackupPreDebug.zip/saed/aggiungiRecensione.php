<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="libro.css" />
</head>

<body>
	<?php 
		session_start();
		function getUrl() {
 			return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
		}
		if(!(isset($_SESSION['username']))) {
			header('Location:'.$_SERVER['HTTP_REFERER']);
		}
		else {
			$client=SoapClient('http://localhost:8080');
			$isbn=getUrl();
			$titolo=$client->leggiTitolo(getUrl());?>
			<div id="contenitoreGrande" class="page_settings_profile">
            	<!-- START HEADER -->
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
                            $username=$_SESSION['username'];
                            echo '<strong>Ciao, $username</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="recensioniUtente.php"><span>La mia recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
                <?php
					$recensione=$client->inserisciRecensione($_SESSION['username'],$isbn,$_POST['text_recensione']);
					if(isset($_POST['invia_recensione'])) {
						if($recensione->return==false) { ?>
							<div id="contenitorePiccolo">
								<div id="content">
									<h3>Aggiungi una recensione al libro <?php echo $titolo ?></h3>
									<form id="form_recensione" name="form_recensione" method="post" action="aggiungiRecensione.php">
										<textarea id="text_recensione" name="text_recensione" cols="60" rows="15">
											Qua puoi inserire la tua recensione...
										</textarea>
										<input id="invia_recensione" name="invia_recensione" type="submit" />
									</form>
								</div>
                			</div> <?php
						}
						else {
							echo 'Recensione aggiunta con successo';
							echo '<a href="'.$_SERVER['HTTP_REFERER'].'">Torna ai libri!</a>';
						}
					}
					else {?>
						<div id="contenitorePiccolo">
							<div id="content">
								<h3>Aggiungi una recensione al libro <?php echo $titolo ?></h3>
								<form id="form_recensione" name="form_recensione" method="post" action="aggiungiRecensione.php">
									<textarea id="text_recensione" name="text_recensione" cols="60" rows="15">
										Qua puoi inserire la tua recensione...
									</textarea>
									<input id="invia_recensione" name="invia_recensione" type="submit" />
								</form>
							</div>
						</div> <?php
					}
				?>                
                <!-- END CONTENUTO -->
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href=""> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href="http://www.anobii.com/api_home"> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="http://www.anobii.com/contact" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
        	</div> <?php
      	}
   	?>
</body>
</html>