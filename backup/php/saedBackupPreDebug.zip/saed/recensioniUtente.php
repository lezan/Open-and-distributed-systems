<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="recensioniUtente.css" />
</head>

<body>
	<?php
		/* C'è un problema sul bottone di modifica e cancellazione delle recensioni. Come si fa a dire alla funzione
		qual è il libro su cui si vuole operare?*/
		session_start();
		if(!(isset($_SESSION['username']))) {
			header('Location:login.php');
		}
		else {?> 
			<div id="contenitoreGrande" class="page_settings_profile">
                <!-- START HEADER -->
                <div id="dashboard">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options">
                            <strong>Ciao, <?php echo $_SESSION['username'];?></strong>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="recensioniUtente.php"><span>Le mie recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
                <div id="contenitorePiccolo">
                    <div id="content">
                        <div id="titolo_content">
                            <h3>Le mie recensioni</h3>
                            <h6>Qua sono visualizzate tutte le rencesioni da te sottomesse</h6>
                        </div>
                        <?php
							/* Scrivere in Java la funzione che permette di leggere le recensioni.
							Modificare in seguito gli indici usati in $result a seconda di dove verranno collocati i risultati.
							La tabella 'commenti' non ha come campo il titolo del libro ma solo l'isbn.
							Allora possiamo modificare aggiungendo una ricerca per isbn e poi prendiamo il titolo da lì.*/
							$client= new SoapClient('http://localhost:8080/');
							$result=$client->leggiRecensioniUtente($_SESSION['username']);
							if($result[0][0]->return=='') {?>
                            	<div id="error_recensione"><?php
									echo 'Nessuna recensione da visualizzare';?>
                                </div><?php
							}
							else {
								?>
                                <table><?php
									foreach($result as $v1) { 
                                    	$estratto=substr($v1['corpo'],0,50);?>
										<tr>
                                            <td>
                                            	<?php
													$link='/books/'.$v1['titolo'];
													print '<a id="titolo_libro href="'.$link.'"><span>'.$v1['titolo'].'</span></a>'; 
												?>
                                                <!-- <a id="titolo_libro" href="#"><span>--><?php /*echo $v1['titolo']*/?><!--</span></a>-->
                                            </td>
                                            <td>
                                                <ul>
                                                    <li><a href=""><span><?php echo $estratto;?></span></a></li>
                                                    <li><span><?php echo $v1['data']?></span></li>
                                                </ul>
                                            </td>
                                            <td id="bottoni">
                                            	<!-- Con questi bottoni mi sa che è un casino. Bisogna capire come dire
                                                alla funzione che cancella o modifica le recensione qual è il libro su cui
                                                si vuole operare -->
                                                <?php
													$linkMod='/modifica/recensione/'.$v1['isbn'];
													print '<a href="'.$linkMod.'">Modifica</a>';
												?>
                                                <br />
                                                <?php
													$linkCanc='/cancella/recensione/'.$v1['isbn'];
													print '<a href="'.$linkCanc.'">Cancella</a>';
												?>
                                        	</td>
										</tr> <?php
									} ?>
                                </table><?php
							}?>						
                    </div>
                </div>
                <!-- END CONTENUTO -->
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href=""> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href="http://www.anobii.com/api_home"> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="http://www.anobii.com/contact" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
    		</div><?php
		}
	?>
</body>
</html>