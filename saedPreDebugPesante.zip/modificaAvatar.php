<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="modificaAvatar.css" />
    <link rel="stylesheet" type="text/css" href="profiloUser.css" />
</head>
<body> 
	<?php
		session_start();
		if(isset($_SESSION['username'])) { ?>
			<div id="contenitoreGrande" class="page_settings_profile">
	        <!-- START HEADER -->
	        <div id="dashboard">
	            <ul>
	                <li>
	                    <a href="cerca.php" title="cerca">Cerca il libro</a>
	                </li>
	                <li id="dashboard_options">
	                    <strong>Ciao, <?php echo $_SESSION['username'];?></strong>
	                    |
	                    <a href="logout.php" title="Esci"><span>Esci</span></a> 
	                </li>
	            </ul>
	        </div>
	        <div id="header2">
	            <div id="logo" class="">
	                <span><a href="index.php" title="Logo | Home">Logo</a></span> 
	            </div>
	            <div id="menus">   
	                <ul id="main_menu">
	                    <li id="tab_A">
	                        <a href="index.php"><span>Pagina iniziale</span></a>
	                    </li>
	                    <li id="tab_B">
	                        <a href="recensioniUtente.php"><span>Le mie recensioni</span></a>
	                    </li>
	                    <li id="tab_C">
	                        <a href="profiloUser.php"><span>Profilo</span></a>
	                    </li>
	                </ul>
	            </div>
	        </div>
	        <!-- END HEADER -->
	        <!-- START CONTENUTO -->
	        <div id="contenitorePiccolo">
	            <div id="content">
	            	<?php
	            		$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
							if(isset($_POST['submit'])) {
					    		$name=$_FILES['myfile']['name'];
					    		$tmp_name=$_FILES['myfile']['tmp_name'];
					    		if($name) {
					        		$location="avatars/$name";       		
									$handle=fopen($tmp_name, "r");
									$imgBinary=fread($handle, filesize($tmp_name));
									$img_str = base64_encode($imgBinary);
									fclose($handle);
									$result=$client->uploadAvatar(array('percorso'=>$location,'image'=>$img_str,'username'=>$_SESSION['username']));
									if($result->return==0) { ?>
										<div id="">
											<h3>Avatar impostato con successo.</h3>
											<br/>
											<a href="profiloUser.php">Torna al tuo profilo</a>										
										</div> <?php
									}
					    			else { ?>
					        			<div id="error">
					        				<h3>Inserisci un immagine.</h3>
					        			</div> <?php
					    			}
					    		}
					    	} 
					    	else { ?>
						    	<h3>Cambia la tua immagine</h3>
						    	<h6>Seleziona tramite "sfoglia" l'immagine che vuoi utilizzare come tuo avatar</h4>
								<form id="formUpload" action='modificaAvatar.php' method='POST' enctype='multipart/form-data'>
									<input type='file' name='myfile' value="Sfoglia">
									<input type='submit' name='submit' value='Carica'>
								</form> <?php
							} ?>
		            </div>
		        </div>
		        <!-- END CONTENUTO -->       
		        <!-- START FOOTER -->
		        <div id="footer">
		            <ul id="links_footer">
		                <li class="item_footer">
		                    <a href=""> Il nostro progetto</a>
		                </li>
		                <li class="item_footer">
		                    <a href=""> Chi siamo?</a>
		                </li>
		                <li class="item_footer">
		                    <a href="" class="last"> Contattaci</a>
		                </li>
		            </ul>
		        </div>
		        <!-- END FOOTER -->
		    </div><?php			
		}
		else {
			header('Location:login.php');
		}		
	?>
</body>
</html>