<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="login.css" />
<link rel="stylesheet" type="text/css" href="footer.css" />
<link rel="stylesheet" type="text/css" href="messages.css" />
</head>

<body>
	<?php
		session_start();
		if(isset($_SESSION['username'])|| isset($_SESSION['email'])) {
			header('Location:index.php');
		}
		else {
			$client = new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
			if((isset($_POST['username'])&&isset($_POST['userPassword']))||(isset($_POST['email'])&&isset($_POST['libreriaPassword']))){
				if(isset($_POST['username'])) {
					$parametriUser= array('nickuser'=>$_POST['username'],'passwd'=>$_POST['userPassword']);
					$loginUser=$client->loginUsers($parametriUser);
				}
				if(isset($_POST['email'])) {
					$parametriLibreria=array('email'=>$_POST['email'],'passwd'=>$_POST['libreriaPassword']);
					$loginLibreria=$client->loginLibrerie($parametriLibreria);
				}
				if(@$loginUser->return==-1 || @$loginUser->return==-2 || @$loginUser->return==1 || @$loginLibreria->return==-1 || @$loginLibreria->return==-2 || @$loginLibreria->return==1){ ?>
                    <div id="contenitore">
                        <!-- START HEADER -->
                        <div id="header">
                            <div id="header_logo">
                                <a href="index.php">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                            </div>
                            <div id="scritta">
                                <h3 id="slogan">Anarchia.</h3>
                            </div>
                        </div>
                        <!-- END HEADER -->
                        <!-- START CONTENUTO -->
                        <div id="contenutoUser">
                            <div class="signup_header">
                                <h1 id="signup_header_message_user">Accesso, come user</h1>
                            </div>
                            <form id="login_form" action="login.php" method="post">
                                <!-- START LOGIN USER -->
                                <div class="signup_content_main">
                                    <div class="signup_field">
                                        <div class="signup_field_title">
                                            <span>Username</span>:
                                        </div>
                                        <div class="signup_field_input">
                                            <input type="text" id="username" name="username" value="" maxlength="255" />
                                        </div>
                                    </div>
                                    <div class="signup_field">
                                        <div class="signup_field_title">
                                            <span>Password</span>
                                        </div>
                                        <div class="signup_field_input">
                                            <input type="password" id="userPassword" name="userPassword" maxlength="255" />
                                        </div>
                                    </div>
                                    <div class="signup_confirm">
                                          <input type="submit" class="btn_action" value="Accesso" />					
                                    </div>
                                    <div class="forgot_pw">
                                        <a href=""><span>Password dimenticata?</span></a>
                                    </div>
                                </div>
                                <div id="connect_option">
                                    <div id="connect_option_existing">
                                        <h2><span>Non sei ancora membro?</span></h2>
                                        <a href="iscrizioneUser.php" class="signin"><span>Registrati come utente, è gratis!</span></a>
                                    </div>
                                </div>
                                <!-- END LOGIN USER -->
                            </form>
                        </div>
                        <div id="contenutoLibreria">
                            <div class="signup_header">
                                <h1 id="signup_header_message_libreria">Accesso, come libreria</h1>
                            </div>
                            <form id="login_form_2" action="login.php" method="post">
                                <!-- START LOGIN LIBRERIA -->
                                <div class="signup_content_main">
                                    <div class="signup_field">
                                        <div class="signup_field_title">
                                            <span>Email</span>:
                                        </div>
                                        <div class="signup_field_input">
                                            <input type="text" id="email" name="email" value="" maxlength="255" />
                                        </div>
                                    </div>
                                    <div class="signup_field">
                                        <div class="signup_field_title">
                                            <span>Password</span>
                                        </div>
                                        <div class="signup_field_input">
                                            <input type="password" id="libreriaPassword" name="libreriaPassword" maxlength="255" />
                                        </div>
                                    </div>
                                    <div class="signup_confirm">
                                          <input type="submit" class="btn_action" value="Accesso" />					
                                    </div>
                                    <div class="forgot_pw">
                                        <a href=""><span>Password dimenticata?</span></a>
                                    </div>
                                </div>
                                <div id="connect_option">
                                    <div id="connect_option_existing">
                                        <h2><span>Non sei ancora membro?</span></h2>
                                        <a href="iscrizioneLibreria.php" class="signin"><span>Registrati come libreria, è gratis!</span></a>
                                    </div>
                                </div>
                                <!-- END LOGIN LIBRERIA -->
                            </form>
                        </div>
                        <!-- END CONTENUTO -->
                        <!-- START FOOTER -->
                        <div id="footer">
                            <ul id="links_footer">
                                <li class="item_footer">
                                    <a href=""> Il nostro progetto</a>
                                </li>
                                <li class="item_footer">
                                    <a href=""> Chi siamo?</a>
                                </li>
                                <li class="item_footer">
                                    <a href="" class="last"> Contattaci</a>
                                </li>
                            </ul>
                        </div>
                        <!-- END FOOTER -->
            		</div> <?php
				}
				else {
					if(isset($_POST['username'])) {
  						$_SESSION['username'] = $_POST['username'];
					}
					else if(isset($_POST['email'])) {
						$_SESSION['email'] = $_POST['email'];
					}
					header('Location:index.php');
				}
			}
			else { ?>
				<div id="contenitore">
                    <!-- START HEADER -->
                    <div id="header">
                        <div id="header_logo">
                            <a href="index.php">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                        </div>
                        <div id="scritta">
                            <h3 id="slogan">Anarchia.</h3>
                        </div>
                    </div>
                    <!-- END HEADER -->
                    <!-- START CONTENUTO -->
                    <div id="contenutoUser">
                        <div class="signup_header">
                            <h1 id="signup_header_message_user">Accesso, come user</h1>
                        </div>
                        <form id="login_form" action="login.php" method="post">
                            <!-- START LOGIN USER -->
                            <div class="signup_content_main">
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <span>Username</span>:
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="username" name="username" value="" maxlength="255" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <span>Password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="userPassword" name="userPassword" maxlength="255" />
                                    </div>
                                </div>
                                <div class="signup_confirm">
                                      <input type="submit" class="btn_action" value="Accesso" />					
                                </div>
                                <div class="forgot_pw">
                                    <a href=""><span>Password dimenticata?</span></a>
                                </div>
                            </div>
                            <div id="connect_option">
                                <div id="connect_option_existing">
                                    <h2><span>Non sei ancora membro?</span></h2>
                                    <a href="iscrizioneLibreria.php" class="signin"><span>Registrati come utente, è gratis!</span></a>
                                </div>
                            </div>
                            <!-- END LOGIN USER -->
                        </form>
                    </div>
                    <div id="contenutoLibreria">
                        <div class="signup_header">
                            <h1 id="signup_header_message_libreria">Accesso, come libreria</h1>
                        </div>
                        <form id="login_form_2" action="login.php" method="post">
                            <!-- START LOGIN LIBRERIA -->
                            <div class="signup_content_main">
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <span>Email</span>:
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="email" name="email" value="" maxlength="255" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <span>Password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="libreriaPassword" name="libreriaPassword" maxlength="255" />
                                    </div>
                                </div>
                                <div class="signup_confirm">
                                      <input type="submit" class="btn_action" value="Accesso" />					
                                </div>
                                <div class="forgot_pw">
                                    <a href=""><span>Password dimenticata?</span></a>
                                </div>
                            </div>
                            <div id="connect_option">
                                <div id="connect_option_existing">
                                    <h2><span>Non sei ancora membro?</span></h2>
                                    <a href="iscrizioneLibreria.php" class="signin"><span>Registrati come libreria, è gratis!</span></a>
                                </div>
                            </div>
                            <!-- END LOGIN LIBRERIA -->
                        </form>
                    </div>
                    <!-- END CONTENUTO -->
                    <!-- START FOOTER -->
                    <div id="footer">
                        <ul id="links_footer">
                            <li class="item_footer">
                                <a href=""> Il nostro progetto</a>
                            </li>
                            <li class="item_footer">
                                <a href=""> Chi siamo?</a>
                            </li>
                            <li class="item_footer">
                                <a href="" class="last"> Contattaci</a>
                            </li>
                        </ul>
                    </div>
                    <!-- END FOOTER -->
                </div> <?php
			}
		}
	?>
</body>
</html>
