<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Iscrizione libreria</title>
    <link rel="stylesheet" type="text/css" href="iscrizioneLibreria.css" />
    <link rel="stylesheet" type="text/css" href="footer.css" />
</head>
<!-- Se è loggato mandata all'home, se invece non è loggato si comporta così:
 - se setta tutto restituisce un echo;
 - se non sono tutti settati mostra la pagina di iscrizione;
Dobbiamo fare una cosa più carina per quando invia il modulo di iscrizione, perché far restuire degli echo è brutto.
-->
<script>
  function Check() {
     // Variabili associate ai campi del modulo
     	var nome = document.signUpForm.nome.value;
	var email=document.signUpForm.email.value;
	var password=document.signUpForm.password.value;
	var passwordConfirm=document.signUpForm.passwordConfirm.value;
	var indirizzo = document.signUpForm.indirizzo.value;
     	var citta = document.signUpForm.citta.value;
     	var cap = document.signUpForm.cap.value;
     	var partitaIva = document.signUpForm.partitaIva.value;
	if ((nome == "") ||nome == undefined) {
           alert("Il campo nome è obbligatorio.");
           document.signUpForm.nome.focus();
           return false;
        }
	else if ((email == "") ||email == undefined) {
           alert("Il campo email è obbligatorio.");
           document.signUpForm.email.focus();
           return false;
        }
	else if ((password == "") ||password == undefined) {
           alert("Il campo password è obbligatorio.");
           document.signUpForm.password.focus();
           return false;
        }
	else if ((passwordConfirm == "") ||passwordConfirm == undefined) {
           alert("Il campo conferma password è obbligatorio.");
           document.signUpForm.passwordConfirm.focus();
           return false;
        }
	else if(password.length<8){
		alert("Inserisci una password di almeno 8 caratteri");
        	document.signUpForm.password.focus();
    		return false;
	}
	else if(password!=passwordConfirm){
		alert("Le password non coincidono");
        	document.signUpForm.password.focus();
		return false;
	}
	else if ((indirizzo == "") ||indirizzo == undefined) {
           alert("Il campo indirizzo è obbligatorio.");
           document.signUpForm.indirizzo.focus();
           return false;
        }
	else if ((citta == "") ||citta == undefined) {
           alert("Il campo città è obbligatorio.");
           document.signUpForm.citta.focus();
           return false;
        }
	else if ((cap == "") ||cap == undefined) {
           alert("Il campo cap è obbligatorio.");
           document.signUpForm.cap.focus();
           return false;
        }
	else if ((partitaIva == "") ||partitaIva == undefined) {
           alert("Il campo conferma password è obbligatorio.");
           document.signUpForm.partitaIva.focus();
           return false;
        }
        //INVIA IL MODULO
        else {
           document.signUpForm.submit();
        }
  }
</script>
<body>
	<?php
		session_start();
		if(isset($_SESSION['username'])) {
			header('Location:index.php');
		}
		else {
			if(isset($_POST['nome'])&&isset($_POST['password'])&&isset($_POST['passwordConfirm'])&&isset($_POST['email'])&&isset($_POST['indirizzo'])&&isset($_POST['citta'])&&isset($_POST['cap'])&&isset($_POST['partitaIva'])) {
				$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
				$param=array("nome"=>$_POST['nome'],"passwd"=>$_POST['password'],"passwdc"=>$_POST['passwordConfirm'],"email"=>$_POST['email'],"indirizzo"=>$_POST['indirizzo'],"citta"=>$_POST['citta'],"cap"=>$_POST['cap'],"partitaIva"=>$_POST['partitaIva']);
				$result=$client->iscrizioneLibrerie($param);
				if($result->return==1) {
					echo 'Iscrizione corretta.'; /* Magari mettiamoci qualcosa per far capire che è andata a buon fine*/
				}
				else if($result->return==2) {
					echo 'Errore nella connessione al database.';
				}
				else if($result->return==3) {
					echo 'La password deve almeno 8 caratteri.';
				}
				else if($result->return==4) {
					echo 'Le password non coincidono.';
				}
				else if($result->return==5) {
					echo 'Nome già utilizzato.';
				}
				else if($result->return==6) {
					echo 'Email già utilizzata.';
				}
				else if($result->return==7) {
					echo 'Partita Iva già utilizzata.';
				}
				else if($result->return==8) {
					echo 'Impossibile compiere l\'operazione';
				}
				else {
					echo 'Errore generico. Riprova.';
				}
			}
			else { ?>
                <div id="contenitore">
                    <!-- START HEADER -->
                    <div id="header">
                        <div id="header_logo">
                            <a href="index.php">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                        </div>
                        <div id="scritta">
                            <h3 id="slogan">Anarchia.</h3>
                        </div>
                    </div>
                    <!-- END HEADER -->
                    <!-- START CONTENUTO -->
                    <div id="contenuto">
                        <div class="signup_header">
                            <h1 id="signup_header_message">Iscriviti come libreria</h1>
                        </div>
                        <form name="signUpForm" id="signUpForm" action="iscrizioneLibreria.php" method="post">
                            <div class="signup_content_main">
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Nome</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="nome" name="nome" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Email</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="email" name="email" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="password" name="password" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Inserisci nuovamente la password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="passwordConfirm" name="passwordConfirm" />
                                    </div>
                                </div>		
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Indirizzo</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="indirizzo" name="indirizzo" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Città</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="citta" name="citta" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Cap</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="cap" name="cap" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Partita iva</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="partitaIva" name="partitaIva" maxlength="15"/>
                                    </div>
                                </div>
                                <div class="signup_confirm"> 
                                    <!--<input type="submit" class="btn_action" value="Iscriviti" />-->
					<input type="button" class="btn_action" value="Iscriviti" onClick="Check()"/>
                                </div>
                            </div>
                            <!-- START SIDE -->
                            <div class="signup_content_side D">
                                <div class="signup_content_side_feature discover png_bg">
                                    <h3 class="side_titolo">Cerca</h3>
                                    <h4 class="side_contenuto">Cerca il libro che ti interessa</h4>
                                </div>
                                <div class="signup_content_side_feature reader png_bg">
                                    <h3 class="side_titolo">Acquista</h3>
                                    <h4 class="side_contenuto">Acquista il tuo prossimo libro</h4>
                                </div>
                                <div class="signup_content_side_feature shelf png_bg">
                                    <h3 class="side_titolo">Condividi</h3>
                                    <h4 class="side_contenuto">Valuta e recensisci i tuoi libri</h4>
                                </div>
                            </div>
                            <!-- END SIDE -->
                            <div id="connect_option">
                                <div id="connect_option_existing">
                                    <h2><span>Libreria già esistente?</span></h2>
                                    <a href="login.php" class="signin"><span>Entra</span></a>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- END CONTENUTO -->
                    <!-- START FOOTER -->
                    <div id="footer">
                        <ul id="links_footer">
                            <li class="item_footer">
                                <a href=""> Il nostro progetto</a>
                            </li>
                            <li class="item_footer">
                                <a href=""> Chi siamo?</a>
                            </li>
                            <li class="item_footer">
                                <a href="" class="last"> Contattaci</a>
                            </li>
                        </ul>
                    </div>
                    <!-- END FOOTER -->
            	</div> <?php 
			}
		}
	?>
</body>
</html>
