<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="iscrizioneUser.css" />
</head>
<!-- Se è loggato mandata all'home, se invece non è loggato si comporta così:
 - se setta tutto restituisce un echo;
 - se non sono tutti settati mostra la pagina di iscrizione;
Dobbiamo fare una cosa più carina per quando invia il modulo di iscrizione, perché far restuire degli echo è brutto.
-->

<body>
	<?php
		session_start();
		if(isset($_SESSION['username'])) {
			header('Location:index.php');
		}
		else {
			if(isset($_POST['username'])&&isset($_POST['password'])&&isset($_POST['passwordConfirm'])&&isset($_POST['email'])) {
				$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
				$param=array("nickuser"=>$_POST['username'],"passwd"=>$_POST['password'],"passwdc"=>$_POST['passwordConfirm'],"email"=>$_POST['email']);
				$result=$client->iscrizioneUser($param);
				if($result->return==1) {
					echo 'Iscrizione corretta.'; /* Magari mettiamoci qualcosa per far capire che è andata a buon fine*/
				}
				else if($result->return==2) {
					echo 'Errore nella connessione al database.';
				}
				else if($result->return==3) {
					echo 'La password deve almeno 8 caratteri.';
				}
				else if($result->return==4) {
					echo 'Le password non coincidono.';
				}
				else if($result->return==5) {
					echo 'Nickname già utilizzato.';
				}
				else if($result->return==6) {
					echo 'Email già utilizzata.';
				}
				else if($result->return==7) {
					echo 'Impossibile compiere l\'operazione';
				}
				else {
					echo 'Errore generico. Riprova.';
				}
			}
			else { ?>
                <div id="contenitore">
                    <!-- START HEADER -->
                    <div id="header">
                        <div id="header_logo">
                            <a href="index.php">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                        </div>
                        <div id="scritta">
                            <h3 id="slogan">Anarchia.</h3>
                        </div>
                    </div>
                    <!-- END HEADER -->
                    <!-- START CONTENUTO -->
                    <div id="contenuto">
                        <div class="signup_header">
                            <h1 id="signup_header_message">Iscriviti</h1>
                        </div>
                        <form name="signUpForm" id="signup_form" action="iscrizioneUser.php" method="post">
                            <div class="signup_content_main">
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Username</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="username" name="username" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Email</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="email" name="email" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="password" name="password" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Inserisci nuovamente la password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="passwordConfirm" name="passwordConfirm" />
                                    </div>
                                </div>		
                                <div class="signup_confirm"> 
                                    <input type="submit" class="btn_action" value="Iscriviti" />
                                </div>
                            </div>
                            <!-- START SIDE -->
                            <div class="signup_content_side D">
                                <div class="signup_content_side_feature discover png_bg">
                                    <h3 class="side_titolo">Cerca</h3>
                                    <h4 class="side_contenuto">Cerca il libro che ti interessa</h4>
                                </div>
                                <div class="signup_content_side_feature reader png_bg">
                                    <h3 class="side_titolo">Acquista</h3>
                                    <h4 class="side_contenuto">Acquista il tuo prossimo libro</h4>
                                </div>
                                <div class="signup_content_side_feature shelf png_bg">
                                    <h3 class="side_titolo">Condividi</h3>
                                    <h4 class="side_contenuto">Valuta e recensisci i tuoi libri</h4>
                                </div>
                            </div>
                            <!-- END SIDE -->
                            <div id="connect_option">
                                <div id="connect_option_existing">
                                    <h2><span>Utente già esistente?</span></h2>
                                    <a href="login.php" class="signin"><span>Entra</span></a>
                                </div>
                            </div>
                        </form>			
                    </div>
                    <!-- END CONTENUTO -->
                    <!-- START FOOTER -->
                    <div id="footer">
                        <ul id="links_footer">
                            <li class="item_footer">
                                <a href=""> Il nostro progetto</a>
                            </li>
                            <li class="item_footer">
                                <a href=""> Chi siamo?</a>
                            </li>
                            <li class="item_footer">
                                <a href="" class="last"> Contattaci</a>
                            </li>
                        </ul>
                    </div>
                    <!-- END FOOTER -->
                </div> <?php 
			}
		}
	?>
</body>
</html>