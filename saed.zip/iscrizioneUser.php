<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Iscrizione utente</title>
    <link rel="stylesheet" type="text/css" href="iscrizioneUser.css" />
    <link rel="stylesheet" type="text/css" href="footer.css" />
    <link rel="stylesheet" type="text/css" href="messages.css" />
    <link rel="stylesheet" type="text/css" href="header_logo.css" />
</head>
<script>
	function Check() {
		var username = document.signUpForm.username.value;
		var email=document.signUpForm.email.value;
		var password=document.signUpForm.password.value;
		var passwordConfirm=document.signUpForm.passwordConfirm.value;
		if ((username == "") ||username == undefined) {
         	alert("Il campo username è obbligatorio.");
           	document.signUpForm.username.focus();
			alert("prova");
           	return false;
        }
		else if ((email == "") ||email == undefined) {
			alert("Il campo email è obbligatorio.");
			document.signUpForm.email.focus();
			return false;
		}
		else if ((password == "") ||password == undefined) {
		   alert("Il campo password è obbligatorio.");
		   document.signUpForm.password.focus();
		   return false;
		}
		else if ((passwordConfirm == "") ||passwordConfirm == undefined) {
		   alert("Il campo conferma password è obbligatorio.");
		   document.signUpForm.passwordConfirm.focus();
		   return false;
		}
		else if(password.length<8){
			alert("Inserisci una password di almeno 8 caratteri");
			document.signUpForm.password.focus();
			return false;
		}
		else if(password!=passwordConfirm){
			alert("Le password non coincidono");
			document.signUpForm.password.focus();
			return false;
		}
		else {
		   document.signUpForm.submit();
		}
	}
</script>
<body>
	<?php
		session_start();
		if(isset($_SESSION['username'])) {
			header('Location: index.php');
		}
		else {
			if(isset($_POST['username'])&&isset($_POST['password'])&&isset($_POST['passwordConfirm'])&&isset($_POST['email'])) {
				$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
				$param=array("nickuser"=>$_POST['username'],"passwd"=>$_POST['password'],"passwdc"=>$_POST['passwordConfirm'],"email"=>$_POST['email']);
				$result=$client->iscrizioneUser($param);
				if($result->return==1) {
					$_SESSION['username']=$_POST['username'];
					header( "location:index.php" );
				}
				else if($result->return==2) {
					echo '<div class="error">Errore nella connessione al database.</div>';
				}
				else if($result->return==5) {
					echo '<div class="error">Nickname già utilizzato.</div>';
				}
				else if($result->return==6) {
					echo '<div class="error">Email già utilizzata.</div>';
				}
				else if($result->return==7) {
					echo '<div class="error">Impossibile compiere l\'operazione.</div>';
				}
				else {
					echo '<div class="error">Errore generico. Riprova.</div>';
				}
			}
			else { ?>
                <div id="contenitore">
                    <!-- START HEADER -->
                    <div id="header">
                        <div id="header_logo">
                            <a href="index.php">anobii</a>
                        </div>
                        <div id="scritta">
                            <h3 id="slogan">Un libro al giorno toglie il medico di torno</h3>
                        </div>
                    </div>
                    <!-- END HEADER -->
                    <!-- START CONTENUTO -->
                    <div id="contenuto">
                        <div class="signup_header">
                            <h1 id="signup_header_message">Iscriviti</h1>
                        </div>
                        <form name="signUpForm" id="signup_form" action="iscrizioneUser.php" method="post">
                            <div class="signup_content_main">
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Username</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="username" name="username" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Email</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="text" id="email" name="email" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="password" name="password" />
                                    </div>
                                </div>
                                <div class="signup_field">
                                    <div class="signup_field_title">
                                        <div class="signup_field_checking png_bg"></div>
                                        <span>Inserisci nuovamente la password</span>
                                    </div>
                                    <div class="signup_field_input">
                                        <input type="password" id="passwordConfirm" name="passwordConfirm" />
                                    </div>
                                </div>		
                                <div class="signup_confirm">
									<input type="button" class="btn_action" value="Iscriviti" onClick="Check()"/>
                                </div>
                            </div>
                            <!-- START SIDE -->
                            <div class="signup_content_side D">
                                <div class="signup_content_side_feature discover png_bg">
                                    <h3 class="side_titolo">Cerca</h3>
                                    <h4 class="side_contenuto">Cerca il libro che ti interessa</h4>
                                </div>
                                <div class="signup_content_side_feature reader png_bg">
                                    <h3 class="side_titolo">Acquista</h3>
                                    <h4 class="side_contenuto">Acquista il tuo prossimo libro</h4>
                                </div>
                                <div class="signup_content_side_feature shelf png_bg">
                                    <h3 class="side_titolo">Condividi</h3>
                                    <h4 class="side_contenuto">Valuta e recensisci i tuoi libri</h4>
                                </div>
                            </div>
                            <!-- END SIDE -->
                            <div id="connect_option">
                                <div id="connect_option_existing">
                                    <h2><span>Utente già esistente?</span></h2>
                                    <a href="login.php" class="signin"><span>Entra</span></a>
                                </div>
                            </div>
                        </form>			
                    </div>
                    <!-- END CONTENUTO -->
                    <!-- START FOOTER -->
                    <div id="footer">
                        <ul id="links_footer">
                            <li class="item_footer">
                                <a href="relazione.php"> Il nostro progetto</a>
                            </li>
                            <li class="item_footer">
                                <a href="chisiamo.php"> Chi siamo?</a>
                            </li>
                            <li class="item_footer">
                                <a href="mailto:progettosaed@mailinator.com?Subject=Informazioni" class="last"> Contattaci</a>
                            </li>
                        </ul>
                    </div>
                    <!-- END FOOTER -->
                </div> <?php 
			}
		}
	?>
</body>
</html>
