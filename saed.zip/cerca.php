<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Cerca un libro</title>
    <link rel="stylesheet" type="text/css" href="cerca.css" />
    <link rel="stylesheet" type="text/css" href="footer.css" />
    <link rel="stylesheet" type="text/css" href="messages.css" />
    <link rel="stylesheet" type="text/css" href="header_logo.css" />
    
</head>

<body>
	<?php
		session_start();
	?>
    <div id="contenitoreGrande">
        <!-- START HEADER -->
        <?php
        	$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
			if(isset($_SESSION['username']) || isset($_SESSION['email'])) {
				if(isset($_SESSION['username'])) { ?>
					<div id="dashboard" class="headerLoggato">
						<ul>
							<li>
								<a href="cerca.php" title="cerca">Cerca il libro</a>
							</li>
							<li id="dashboard_options"><?php
								echo '<strong>Ciao, '.$_SESSION['username'].'</strong>'; ?>
								|
								<a href="logout.php" title="Esci"><span>Esci</span></a> 
							</li>
						</ul>
					</div>
					<div id="header2" class="headerLoggato">
						<div id="logo" class="">
							<span><a href="index.php" title="Logo | Home">Logo</a></span> 
						</div>
						<div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="recensioniUtente.php"><span>La mia recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                    </div>
					</div><?php
				}
				else if(isset($_SESSION['email'])) { ?>
					<div id="dashboard" class="headerLoggato">
						<ul>
							<li>
								<a href="cerca.php" title="cerca">Cerca il libro</a>
							</li>
							<li id="dashboard_options"><?php
								$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            	echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
								|
								<a href="logout.php" title="Esci"><span>Esci</span></a> 
							</li>
						</ul>
					</div>
					<div id="header2" class="headerLoggato">
						<div id="logo" class="">
							<span><a href="index.php" title="Logo | Home">Logo</a></span> 
						</div>
						<div id="menus">   
						<ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                   </div>
					</div> <?php
				}
			}
			else { ?>
				<div id="header">
					<div id="header_logo">
						<a href="index.php">anobii</a>
					</div>
					<div id="login">
                        <div id="botton_login">
                            <a href="login.php">Login</a>
                            |
                            <a href="iscrizioneUser.php">Iscriviti</a>
                            |
                            <a href="iscrizioneLibreria.php">Libreria</a>
                        </div>
                    </div>
                    <div id="scritta">
                        <h3 id="slogan">Un libro al giorno toglie il medico di torno</h3>
                    </div>
                </div><?php
			}
		?>
        <!-- END HEADER -->
        <div id="contenitorePiccolo">
            <div id="title_section">
                <div id="search_result">
                    <form id="search_product" class="standard_form" name="search_product" action="cerca.php" method="get">
                        <dl>
                            <?php
                                $client = new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
                                @$campo=array('campo'=>$_GET['cerca_input']);
                                $result=$client->ricerca($campo);
                                if(@$result->return[0]->array[0]=='') { 
                                    $vuoto='true';?>
                                    <dt id="result_amount">
                                        <span><strong>0</strong> risultati trovati</span>
                                    </dt><?php
                                }
                                else {?>
                                    <dt id="result_amount"><?php
                                        $vuoto='false';
													 $nLibri=$client->contaLibriRicerca($campo);	
                                        echo '<span><strong>'.$nLibri->return.'</strong> risultati trovati</span>';?>
                                    </dt><?php
                                }
                            ?>
                            <dd> 
                                <h3><label for="search_keyword"><span>Cerca</span>:</label></h3>
                                <input type="text" id="cerca_input" class="text_input" name="cerca_input" maxlength="150" />
                                <input type="submit" name="search" value="Cerca" />
                                <a href="ricercaAvanzata.php" id="ricerca_avanzata" title="Ricerca avanzata">
                                    <span>Ricerca avanzata</span>
                               	</a>
                            </dd>
                     	</dl>
                    </form>
                </div>
            </div>
            <div id="content">
                <div id="shelf_wrap" class="list_view"> 
                    <div class="shelf">
                        <table id="" class=""> 
							<?php
								if($vuoto=='false') {
									$i=0;
									$j=0;
									for($i=0;$i<$nLibri->return;$i++) {?>
										<tr id="" title="">
											<td class="cover_wrap">
												<a class="cover_image" href="">
													<img border="1" src="" class="book_cover" width="500" height="766" alt="" title="" />
                                               	</a>
											</td>
											<td>
												<ul class="item_text">
													<?php
														for($j=0;$j<8;$j++) {
															if($j==0) { //Titolo libro
																print '<li class="title">'.$result->return[$i]->array[$j].'</li>';
															}
															if($j==1) { //Autore libro
																print '<li class="contributor"><span><a href="/autore/'.$result->return[$i]->array[$j].'">'.$result->return[$i]->array[$j].'</a></span></li>';
															}
															if($j==4) { //ISBN libro
																print '<li class="meta"><span><a href="/books/'.$result->return[$i]->array[$j].'">'.$result->return[$i]->array[$j].'</span></li>';
															}
														}
													?>
												</ul>
											</td>
										</tr> <?php
									}
								}
								else {
									echo '<div class="error">Nessun risultato per questa ricerca</div>';														
								}
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>	
        <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href="relazione.php"> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href="chisiamo.php"> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="mailto:progettosaed@mailinator.com?Subject=Informazioni" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
        <!-- END FOOTER -->
    </div>
</body>
</html>
