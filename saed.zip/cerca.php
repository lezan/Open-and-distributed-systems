<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="cerca.css" />
</head>

<body>
	<?php
		session_start();
		/* L'utente è connesso e quindi non vedrà in alto il bottone di login, bensì dei link che lo portano al modifica del suo
		profilo ed altre cose. Questo dovremmo farlo per ogni pagina. Controllare sempre se è loggato e agire di conseguenza ( cioè levare
		il bottone in alto di loggarsi e iscriversi. 
		Qualcosa di questo genere.
		Qualcosa ho fatto, vediamo se ci aggrada; in sostanza - come avviene anche nella pagina index.php - se sei loggato non ti mostra
		il solito header, bensì, a seconda che tu sia una libreria o un utente, ti mostra un header differente da quando non sei loggato;
		la differenza tra l'header di libreria e di utente è minima: la libreria ha un link per vedere i suoi libri (implementare in java
		una funzione che, data il nome della libreria (o l'email), restituisca tutti i libri di quella libreria(in pratica una ricerca per
		libreria), mentre l'utente ha link per vedere le recensioni da lui rilasciate su tutti i libri ( questa non ricordo come abbiamo
		fatto le tabelle, quindi ulteriori dettagli dovranno essere rimandati.
		Che ne pensi?
		Possiamo aggiungere qualcosa nel div "side". Idee?!
		GROSSO ERRORE NELLA STAMPA: bisogna cambiare la posizione del foreach, deve andare fuori di ogni <tr>. Un devo rimanere dentro ad 
		ogni <ul>.
		Dovrei aver corretto questo ultimo errore che avevo detto.
		Bisogna ora controllare se stampa correttamente.*/
	?>
    <div id="contenitoreGrande">
        <!-- START HEADER -->
        <?php
        	$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
			if(isset($_SESSION['username']) || isset($_SESSION['email'])) {
				if(isset($_SESSION['username'])) { ?>
					<div id="dashboard" class="headerLoggato">
						<ul>
							<li>
								<a href="cerca.php" title="cerca">Cerca il libro</a>
							</li>
							<li id="dashboard_options"><?php
								echo '<strong>Ciao, '.$_SESSION['username'].'</strong>'; ?>
								|
								<a href="logout.php" title="Esci"><span>Esci</span></a> 
							</li>
						</ul>
					</div>
					<div id="header2" class="headerLoggato">
						<div id="logo" class="">
							<span><a href="index.php" title="Logo | Home">Logo</a></span> 
						</div>
						<div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="recensioniUtente.php"><span>La mia recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                    </div>
					</div><?php
				}
				else if(isset($_SESSION['email'])) { ?>
					<div id="dashboard" class="headerLoggato">
						<ul>
							<li>
								<a href="cerca.php" title="cerca">Cerca il libro</a>
							</li>
							<li id="dashboard_options"><?php
								$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            	echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
								|
								<a href="logout.php" title="Esci"><span>Esci</span></a> 
							</li>
						</ul>
					</div>
					<div id="header2" class="headerLoggato">
						<div id="logo" class="">
							<span><a href="index.php" title="Logo | Home">Logo</a></span> 
						</div>
						<div id="menus">   
						<ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                   </div>
					</div>
			<?php
				}
			}
			else { ?>
				<div id="header">
					<div id="header_logo">
						<a href="index.php">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
					</div>
					<div id="login">
                        <div id="botton_login">
                            <a href="login.php">Login</a>
                            |
                            <a href="iscrizioneUser.php">Iscriviti</a>
                            |
                            <a href="iscrizioneLibreria.php">Libreria</a>
                        </div>
                    </div>
                    <div id="scritta">
                        <h3 id="slogan">Anarchia.</h3>
                    </div>
                </div><?php
			}
		?>
        <!-- END HEADER -->
        <div id="contenitorePiccolo">
            <div id="title_section">
                <div id="search_result">
                    <form id="search_product" class="standard_form" name="search_product" action="cerca.php" method="get">
                        <dl>
                            <?php
                                $client = new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
                                @$campo=array('campo'=>$_GET['cerca_input']);
                                $result=$client->ricerca($campo);
                                //$temp=(array)$result;
                                //echo serialize($temp);
                                /*echo '<pre>';
										  var_dump($result);
										  echo '</pre>';*/
                                if(@$result->return[0]->array[0]=='') { 
                                    $vuoto='true';?>
                                    <dt id="result_amount">
                                        <span><strong>0</strong> risultati trovati</span>
                                    </dt><?php
                                }
                                else {?>
                                    <dt id="result_amount"><?php
                                        $vuoto='false';
													 $nLibri=$client->contaLibriRicerca($campo);	
                                        echo '<span><strong>'.$nLibri->return.'</strong> risultati trovati</span>';?>
                                    </dt><?php
                                }
                            ?>
                            <dd> 
                                <h3><label for="search_keyword"><span>Cerca</span>:</label></h3>
                                <input type="text" id="cerca_input" class="text_input" name="cerca_input" maxlength="150" />
                                <input type="submit" name="search" value="Cerca" />
                                <a href="ricercaAvanzata.php" id="ricerca_avanzata" title="Ricerca avanzata">
                                    <span>Ricerca avanzata</span></a>
                            </dd>
                     	</dl>
                    </form>
                </div>
            </div>
            <div id="content">
                <div id="shelf_wrap" class="list_view"> 
                    <div class="shelf">
                        <table id="" class=""> 
							<?php
								if($vuoto=='false') {
									$i=0;
									$j=0;
									for($i=0;$i<$nLibri->return;$i++) {?>
										<tr id="" title="">
											<td class="cover_wrap">
												<a class="cover_image" href="">
												<img border="1" src="" class="book_cover" width="500" 
														height="766" alt="" title="" /></a>
											</td>
											<td>
												<ul class="item_text">
													<?php
														for($j=0;$j<8;$j++) {
															if($j==0) { //Titolo libro
																print '<li class="title">'.$result->return[$i]->array[$j].'</li>';
															}
															if($j==1) { //Autore libro
																print '<li class="contributor"><span><a href="/autore/'.$result->return[$i]->array[$j].'">'.$result->return[$i]->array[$j].'</a></span></li>';
															}
															if($j==4) { //ISBN libro
																print '<li class="meta"><span><a href="/books/'.$result->return[$i]->array[$j].'">'.$result->return[$i]->array[$j].'</span></li>';
															}
														}
													?>
												</ul>
											</td>
										</tr> <?php
									}
								}
								else {
									echo '<span id="no_found">Nessun risultato per questa ricerca</span>';														
								}
                            ?>
                        </table>
                    </div>
                </div>
            </div>
            <div id="sidebar">
            </div>
        </div>	
        <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href=""> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href=""> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
        <!-- END FOOTER -->
    </div>
</body>
</html>