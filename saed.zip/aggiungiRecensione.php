<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="/recensioniUtente.css" />
</head>

<body>
	<?php 
		session_start();
		$client=new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
		if(!(isset($_SESSION['username']))) {
			header('Location:/index.php');
		}
		$parametri=array("nickname"=>$_SESSION['username'],"isbn"=>$_GET['ISBN']);
		$result=$client->leggiRecensione($parametri);
		if($result->return[1]!=""){
			echo 'Dott. Alzheimer: hai già inserito una recensione per questo libro</br>';
			echo '<a href="/index.php">Torna ai libri</a>';
		}
		else {
			$client=new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
			$parametri=array("isbn"=>$_GET['ISBN']);
			$titolo=$client->leggiTitolo($parametri);?>
			<div id="contenitoreGrande" class="page_settings_profile">
            	<!-- START HEADER -->
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="/cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
                            echo '<strong>Ciao,'.$_SESSION['username'].'</strong>'; ?>
                            |
                            <a href="/logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="/index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="/index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="/recensioniUtente.php"><span>La mia recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="/profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                     </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
                <?php
					if(isset($_POST['invia_recensione'])) {
						$parametri=array("nickname"=>$_SESSION['username'],"ISBN"=>$_GET['ISBN'],"corpo"=>$_POST['text_recensione']);
						$recensione=$client->inserisciRecensione($parametri);
						if($recensione->return==false) { ?>
							<div id="contenitorePiccolo">
								<div id="content">
									<h3>Aggiungi una recensione al libro <?php echo $titolo->return; ?></h3>
									<form id="form_recensione" name="form_recensione" method="post" action="/aggiungiRecensione.php">
										<textarea id="text_recensione" name="text_recensione" cols="60" rows="15">Qua puoi inserire la tua recensione...</textarea>
										<input id="invia_recensione" name="invia_recensione" value="Invia recensione" type="submit" />
									</form>
								</div>
                			</div> <?php
						}
						else {
							echo 'Recensione aggiunta con successo';
							echo '<a href="/index.php">Torna ai libri!</a>';
						}
					}
					else {?>
						<div id="contenitorePiccolo">
							<div id="content">
								<h3>Aggiungi una recensione al libro <?php echo $titolo->return; ?></h3>
								<form id="form_recensione" name="form_recensione" method="post" action="/aggiungiRecensione.php?ISBN=<?php echo $_GET['ISBN'];?>">
									<textarea id="text_recensione" name="text_recensione" cols="60" rows="15">Qua puoi inserire la tua recensione...</textarea>
									<input id="invia_recensione" name="invia_recensione" value="Invia recensione" type="submit" />
								</form>
							</div>
						</div> <?php
					}
				?>                
                <!-- END CONTENUTO -->
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href=""> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href=""> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
        	</div> <?php
      	}
   	?>
</body>
</html>
