<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Benvenuto nella libreria</title>
    <link rel="stylesheet" type="text/css" href="chisiamo.css" />
    <link rel="stylesheet" type="text/css" href="footer.css" />
    <link rel="stylesheet" type="text/css" href="messages.css" />
    <link rel="stylesheet" type="text/css" href="header_logo.css" />
    
</head>
<body>
	<?php 
		session_start();
	?>
    <div id="contenitore">
        <!-- START HEADER --><?php
        if(isset($_SESSION['username']) || isset($_SESSION['email'])) {
            if(isset($_SESSION['username'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
                            $username=$_SESSION['username'];
                            echo '<strong>Ciao, '.$username.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="/home" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="recensioniUtente.php"><span>Le mie recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                     </div>
                </div><?php
            }
            else if(isset($_SESSION['email'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
							$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                     </div>
                </div>
        <?php
            }
        }
        else {?>
            <div id="header">
                <div id="header_logo">
                    <a href="index.php">anobii</a>
                </div>
                <div id="login">
                    <div id="botton_login">
                        <a href="login.php">Login</a>
                        |
                        <a href="iscrizioneUser.php">Iscriviti</a>
                        |
                        <a href="iscrizioneLibreria.php">Libreria</a>
                    </div>
                </div>
                <div id="scritta">
                    <h3 id="slogan">Un libro al giorno toglie il medico di torno</h3>
                </div>
            </div><?php
        }?>
        <!-- END HEADER -->
        <!-- START CONTENUTO -->
        <div id="contenuto">
		<img src="/photos/chisiamo.jpg" alt="chisiamo"></img>
		<div id="contenuto_sinistra">
            		<span>Giulio Biondi, secondo da sinistra. Nato a Narni nel 1918, si professa comunista, porchettaro e non vota.</span>
		</div>
		<div id="contenuto_destra">
			<span>Leonardo Zanchi, terzo da sinistra. Nato ad Orvieto nel 1947, si professa hacker, vegetariano e vota Udeur</span>
		</div>
        </div>
        <!-- END CONTENUTO -->
         <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href="/relazione.php"> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href="/chisiamo.php"> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="mailto:progettosaed@mailinator.com?Subject=Informazioni" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
        <!-- END FOOTER -->
    </div>
</body>
</html>
