<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="libriLibreria.css" />
</head>
<body>
	<?php
		session_start();
		function getUrl() {
 			return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
		}
		if(!(isset($_SESSION['email']))) {
			header('Location:login.php');
		}
		else {
			$client=SoapClient('http://localhost:8080/');
			$ISBN=getUrl();
			/*$ISBN=$client->leggiISBN(getUrl()); da come hai scritto nel leggimi, creeremo l'url direttamente con l'isbn, perciò questo non dovrebbe servire*/
			$result=$client->deleteLibro($_SESSION['email'],$ISBN);
			if ($result!=1){
				if ($result==2)
					echo 'Errore di connessione al database';
				else if ($result==3)
					echo 'Errore:libro non presente';
				else if ($result==4)
					echo 'Errore sql';
				echo '<form name="error" method="POST" action="libriLibreria.php>';
				echo '<input type="submit" value="Torna alla lista"/>';
				echo '</form>';
			}
			else {
				header("Location:libriLibreria.php");
			}
		}
	?>
</body>
</html>
