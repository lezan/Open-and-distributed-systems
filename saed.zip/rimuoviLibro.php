<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Cancella libro</title>
    <link rel="stylesheet" type="text/css" href="/libriLibreria.css" />
    <link rel="stylesheet" type="text/css" href="/messages.css" />
</head>
<body>
	<?php
		session_start();
		if(!(isset($_SESSION['email']))) {
			header('Location:/login.php');
		}
		else {
			$client=new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
			$ISBN=$_GET['ISBN'];
			$result=$client->deleteLibro(array("email"=>$_SESSION['email'],"ISBN"=>$ISBN));
			if ($result->return!=0){
				if ($result->return==-1){
					echo '<div class="error">Errore di connessione al database</div><br/>';
						echo '<form name="error" method="POST" action="/libriLibreria.php>';
						echo '<input type="submit" value="Torna alla lista"/>';
						echo '</form>';
				}
				else if ($result->return==3){
					echo '<div class="error">Errore:libro non presente</div><br/>';
					echo '<form name="error" method="POST" action="/libriLibreria.php>';
					echo '<input type="submit" value="Torna alla lista"/>';
					echo '</form>';
				}
				else if ($result->return==4){
					echo '<div class="error">Errore sql</div><br/>';
					echo '<form name="error" method="POST" action="/libriLibreria.php>';
					echo '<input type="submit" value="Torna alla lista"/>';
					echo '</form>';
				}
			}
			else {
				header("Location:/libriLibreria.php");
			}
		}
	?>
</body>
</html>
