<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Benvenuto nella libreria</title>
    <link rel="stylesheet" type="text/css" href="index.css" />
	<link rel="stylesheet" type="text/css" href="footer.css" />    
    <link rel="stylesheet" type="text/css" href="messages.css" />
</head>
<body>
	<?php 
		session_start();
	?>
    <div id="contenitore">
        <!-- START HEADER --><?php
        if(isset($_SESSION['username']) || isset($_SESSION['email'])) {
            if(isset($_SESSION['username'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
                            $username=$_SESSION['username'];
                            echo '<strong>Ciao, '.$username.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="/home" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="recensioniUtente.php"><span>Le mie recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                     </div>
                </div><?php
            }
            else if(isset($_SESSION['email'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
							$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                     </div>
                </div> <?php
            }
        }
        else { ?>
            <div id="header">
                <div id="header_logo">
                    <a href="">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                </div>
                <div id="login">
                    <div id="botton_login">
                        <a href="login.php">Login</a>
                        |
                        <a href="iscrizioneUser.php">Iscriviti</a>
                        |
                        <a href="iscrizioneLibreria.php">Libreria</a>
                    </div>
                </div>
                <div id="scritta">
                    <h3 id="slogan">Anarchia.</h3>
                </div>
            </div><?php
        } ?>
        <!-- END HEADER -->
        <!-- START TOP -->
        <div id="top">
            <div id="top_libreria"> Cerca </div>
            <div id="top_find"> Acquista </div>
            <div id="top_share"> Condividi </div>
            <div id="top_destro">
                <div class="top_destro_contenitore">
                    <h3 class="top_destro_titolo"> Cerca </h3>
                    <span class="top_destro_contentuto"> Cerca il libro che ti interessa </span>
                </div>
                <div class="top_destro_contenitore"> 
                    <h3 class="top_destro_titolo"> Acquista </h3>
                    <span class="top_destro_contentuto"> Acquistalo da uno dei nostri venditori </span>
                </div>
                <div class="top_destro_contenitore">
                    <h3 class="top_destro_titolo"> Condividi </h3>
                    <span class="top_destro_contentuto"> Valuta e recensisci i libri che hai acquistato e letto </span>
                </div>
            </div>
        </div>
        <!-- END TOP -->
        <!-- START CERCA -->
        <div id="cerca">
            <form action="cerca.php" method="get" >
                <input type="text" id="cerca_input" name="cerca_input" value="Cerca il tuo libro" />
                <input type="submit" id="cerca_bottone" value="Cerca"  />
            </form>
        </div>
        <!-- END CERCA -->
        <!-- START CONTENUTO -->
        <div id="contenuto">
            <div id="contenuto_sinistra" class="colonne">
                <h2 id="titolo_contenuto_sinistra">Aggiunti di recente</h2>
               	<?php 
					$client = new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
					$result=$client->listaNovita();
					if($result->return==null) {
						echo '<div class="error">Nessun libro presente</div>';
					}
					else {?>
						<ul class="liste"> <?php
							for($i=0; $i< count($result->return); $i++) { ?>
								<li>								
									<div class="celle_contenuto">
										<?php
											$temp=$client->leggiISBN(array('titolo'=>$result->return[$i]->array[0]));
											print '<a href="/books/'.$temp->return.'"><span>'.$result->return[$i]->array[0].'</span></a>';
										?>
										, di <?php
											print '<a href="/autore/'.$result->return[$i]->array[1].'"><span>'.$result->return[$i]->array[1].'</span></a>';
										?>
										: <?php
											echo $result->return[$i]->array[2];
										?>
									</div>
								</li> <?php 
							} ?>
						</ul> <?php 
					} 
				?>                
            </div>
            <div id="contenuto_centro" class="colonne">
                <h2>Recensioni recenti</h2>
				<?php
              		$client=new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
					$result2=$client->ultimeRecensioni();
					if($result2->return==null) { //Qualcosa non è andato a buon fine nella funzione
						echo '<div class="error">Nessuna recensione presente</div>';
					}
					else {?>
						<ul class="liste"><?php
							for($i=0; $i< count($result2->return);$i++) {?>
                                <li>								
                                    <div class="celle_contenuto">
                                        <?php
                                            $location=$client->cercaAvatar(array('username'=>$result2->return[$i]->array[0]));
                                            if($location->return=='default') {
                                                echo '<img width="15px" height="15px" src="/icon_sample.gif" />';
                                            }
                                            else if($location->return!=null) {
                                                echo '<a href="/'.$location->return.'"><img width="15px" height="15px" src="/'.$location->return.'" /></a>';
                                            } 
                                        ?>
                                        <a href=""><?php echo $result2->return[$i]->array[0];?></a> 
                                         ha recensito
                                        <?php
                                            $temp2=$client->leggiISBN(array('titolo'=>$result2->return[$i]->array[1]));
                                            print '<a href="/books/'.$temp2->return.'"><span>'.$result2->return[$i]->array[1].'</span></a>';
                                        ?>
                                        , di 
                                        <?php
                                            print '<a href="/autore/'.$result2->return[$i]->array[2].'"><span>'.$result2->return[$i]->array[2].'</span></a>';
                                        ?>
                                    </div>
                                </li> <?php 
							} ?>
						</ul> <?php 
					} 
				?>                
            </div>
            <div id="contenuto_destra" class="colonne">
                <h2>I libri più votati</h2>                
                <?php 
					$client = new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
                    $result3=$client->mostraVoti();
                    if($result3->return==null) {//Qualcosa non è andato a buon fine nella funzione
                        echo '<div class="error">Nessun voto presente</div>';
                    }
                    else { ?>
                        <ul class="liste"> <?php 
							for($i=0;$i< count($result3->return);$i++) { ?>
                                <li>						
                                    <div class="celle_contenuto">
                                    	<?php
                                    		$temp3=$client->leggiISBN(array('titolo'=>$result3->return[$i]->array[0]));
                                            print '<a href="/books/'.$temp3->return.'"><span>'.$result3->return[$i]->array[0].'</span></a>';
										?>
                                        , di
                                        <?php
											print '<a href="/autore/'.$result3->return[$i]->array[1].'"><span>'.$result3->return[$i]->array[1].'</span></a>';
										?>
                                        : 
										<?php echo $result3->return[$i]->array[2];?>
                                    </div>
                                </li> <?php 
							} ?>
                        </ul> <?php 
					} 
				?>                
            </div>
        </div>
        <!-- END CONTENUTO -->
        <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href="relazione.php"> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href="chisiamo.php"> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="mailto:progettosaed@mailinator.com?Subject=Informazioni" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
        <!-- END FOOTER -->
    </div>
</body>
</html>
