<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="index.css" />
</head>

<body>
	<div id="contenitore">
    	<!-- START HEADER -->
    	<div id="header">
        	<div id="header_logo">
            	<a href="">La disoccupazione ti ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
            </div>
            <div id="login">
                <div id="botton_login">
                    <a href="">Login</a>
  					|
                    <a href="">Iscriviti</a>
                </div>
        	</div>
            <div id="scritta">
            	<h3 id="slogan">Anarchia.</h3>
            </div>
        </div>
        <!-- END HEADER -->
        <!-- START TOP -->
        <div id="top">
        	<div id="top_libreria"> Cerca </div>
      		<div id="top_find"> Acquista </div>
      		<div id="top_share"> Condividi </div>
      		<div id="top_destro">
       			<div class="top_destro_contenitore">
        			<h3 class="top_destro_titolo"> Cerca </h3>
        			<span class="top_destro_contentuto"> Cerca il libro che ti interessa </span>
       			</div>
       			<div class="top_destro_contenitore"> 
                	<h3 class="top_destro_titolo"> Acquista </h3>
        			<span class="top_destro_contentuto"> Acquistalo da uno dei nostri venditori </span>
       			</div>
       			<div class="top_destro_contenitore">
        			<h3 class="top_destro_titolo"> Condividi </h3>
        			<span class="top_destro_contentuto"> Valuta e recensisci i libri che hai acquistato e letto </span>
       			</div>
      		</div>
        </div>
        <!-- END TOP -->
        <!-- START CERCA -->
        <div id="cerca">
        	<form action="" method="post" >
            	<input type="text" id="cerca_input" value="Cerca il tuo libro" />
                <input type="submit" id="cerca_bottone" value="Cerca"  />
            </form>
        </div>
        <!-- END CERCA -->
        <!-- START CONTENUTO -->
        <div id="contenuto">
        	<div id="contenuto_sinistra" class="colonne">
            	<h2 id="titolo_contenuto_sinistra">Aggiunti di recente</h2>
                <!-- Qua ci mettiamo una lista degli ultimi libri aggiunti al catalogo -->
                <?php
					/*
					Forse dobbiamo introdurre un campo nella tabella che tenga informazioni sulla data di introduzione
					del libro, sia giorno che ora.
					Aggiungere anche la funzione che si occupa di costruire una matrice che contenga le informazioni per
					mostrare le novità, ovvero:
					[titolo][autore][data*]
					...
					[titolo][autore][data*]
					Deve restituire questa matrice.
					In input non prenden nulla.
					*/
					$client = new SoapClient('http://localhost:8080/Libr/services/Server?wsdl');
					$result=array();
					$result=$client->listaNovita();
					if($result[0]->return==-1) { //Qualcosa non è andato a buon fine nella funzione
						echo 'Non mi sento bene';
					}
					else {
						echo '<ul class="liste">';
						for($i=0;$i<4;$i++) {
							echo '<li>';								
							echo '<div class="celle_contenuto>';
							echo '<a href="">$result[i][0]</a>, di <a href="">$result[i][1]</a>: $result[i][2];';
							echo '</div>';
							echo '</li>';
						}
						echo '</ul>';
					}
				?>
            </div>
            <div id="contenuto_centro" class="colonne">
            	<h2>Recensioni recenti</h2>
                <!-- Qua ci mettiamo le ultime recensione scritte -->
                <?php
				/*
				Dobbiamo creare una funzione in java che si occupa di trovare le ultime recensioni sottoscritte.
				La funzione non riceve nulla in input.
				La funzione restituisce una matrice così composta:
				[autoreRecensioni][titoloLibro][autoreLibro]
				...
				[autoreRecensioni][titoloLibro][autoreLibro]
				*/
					$client = new SoapClient('http://localhost:8080/Libr/services/Server?wsdl');
					$result=array();
					$result=$client->ultimeRecensioni();
					if($result[0]->return==-1) { //Qualcosa non è andato a buon fine nella funzione
						echo 'Non mi sento bene';
					}
					else {
						echo '<ul class="liste">';
						for($i=0;$i<4;$i++) {
							echo '<li>';								
							echo '<div class="celle_contenuto>';
							echo '<a href="">$result[i][0]</a> ha recensito <a href="">$result[i][1]</a>, di <a href="">$result[i][1]</a>';
							echo '</div>';
							echo '</li>';
						}
						echo '</ul>';
					}
				?>
            </div>
            <div id="contenuto_destra" class="colonne">
            	<h2>I libri più votati</h2>
                <!-- Qua possiamo metterci i libri con il punteggio più alto -->
                <?php
					$client = new SoapClient('http://localhost:8080/Libr/services/Server?wsdl');
					$result=array();
					/*Implementare la funzione mostraVoti, che lista tutti i libri in ordine di voto decrescente.
					Dovrà restituire una matrice contenente il titolo del libro, l'autore e il voto.
					[titolo][autore][voto*]
					[titolo][autore][voto*]
					...
					[titolo][autore][voto*]
					In input non dovrà ricevere nulla.*/
					$result=$client->mostraVoti();
					if($result[0]->return==-1) {//Qualcosa non è andato a buon fine nella funzione
						echo 'Non mi sento bene';
					}
					else {
						echo '<ul class="liste">';
						for($i=0;$i<4;$i++) {
							echo '<li>';								
							echo '<div class="celle_contenuto>';
							echo '<a href="">$result[i][0]</a>, di <a href="">$result[i][1]</a>: $result[i][2];';
							echo '</div>';
							echo '</li>';
						}
						echo '</ul>';
					}
				?>
            </div>
        </div>
        <!-- END CONTENUTO -->
        <!-- START FOOTER -->
        <div id="footer">
        	<ul id="links_footer">
            	<li class="item_footer">
               		<a href=""> Il nostro progetto</a>
              	</li>
              	<li class="item_footer">
               		<a href="http://www.anobii.com/api_home"> Chi siamo?</a>
              	</li>
             	<li class="item_footer">
               		<a href="http://www.anobii.com/contact" class="last"> Contattaci</a>
              	</li>
            </ul>
        </div>
        <!-- END FOOTER -->
    </div>
</body>
</html>
