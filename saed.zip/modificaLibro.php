<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="libriLibreria.css" />
</head>
<body>
	<?php
		session_start();
		function getUrl() {
 			return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
		}
		if(!(isset($_SESSION['email']))) {
			header('Location:login.php');
		}
		$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
		if ($action=="modifica"){
			$result2=$client->modificaCatalogo(array($_POST['ISBN'],$_POST['titolo'],$_POST['autore'],$_POST['anno'],$_POST['prezzo'],$_POST['lingua']));
			if ($result2->return!=1) {
				/*usando l'array post qui, evitiamo altre chiamate soap per leggere di nuovo i dati, nel caso di errori*/
				echo '<form name="modificaRecensione" action="modificaRecensione.php" method="POST">';
				echo 'Titolo:<input type="text" name ="titolo" value="'.$_POST['titolo'].'"/><br/>';
				echo 'Autore:<input type="text" name ="autore" value="'.$_POST['autore'].'"/><br/>';
				echo 'Anno:<input type="text" name ="anno" value="'.$_POST['anno'].'"/><br/>';
				echo 'prezzo:<input type="text" name ="prezzo" value="'.$_POST['prezzo'].'"/><br/>';
				echo 'lingua:<input type="text" name ="lingua" value="'.$_POST['lingua'].'"/><br/>';
				echo '<input type="hidden" name="action" value="modifica"/>';
				echo '<input type="hidden" name="ISBN" value="'.$ISBN.'"/>';
				echo '<input type="submit" value="Invia"/><br/>';
				echo '<a href="libriLibreria.php">Torna alla lista dei libri!</a>';
			}
			else {
				header("Location:libriLibreria.php");
			}
		}
		else {
			$ISBN=getUrl();
			$result=$client->leggiLibro($ISBN);
			echo '<form name="modificaRecensione" action="modificaRecensione.php" method="POST">';
			echo 'Titolo:<input type="text" name ="titolo" value="'.$result->return[0].'"/><br/>';
			echo 'Autore:<input type="text" name ="autore" value="'.$result->return[1].'"/><br/>';
			echo 'Anno:<input type="text" name ="anno" value="'.$result->return[2].'"/><br/>';
			echo 'prezzo:<input type="text" name ="prezzo" value="'.$result->return[3].'"/><br/>';
			echo 'lingua:<input type="text" name ="lingua" value="'.$result->return[4].'"/><br/>';
			echo '<input type="hidden" name="action" value="modifica"/>';
			echo '<input type="hidden" name="ISBN" value="'.$ISBN.'"/>';
			echo '<input type="submit" value="Invia"/><br/>';
			echo '<a href="libriLibreria.php">Torna alla lista dei libri!</a>';
			echo '</form>';
		}
	?>
</body>
</html>
