<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Modifica libro</title>
    <link rel="stylesheet" type="text/css" href="/libro.css" />
    <link rel="stylesheet" type="text/css" href="/footer.css" />
    <link rel="stylesheet" type="text/css" href="/messages.css" />
    <link rel="stylesheet" type="text/css" href="/header_logo.css" />
</head>
<script>
	function Check() {
  		var copie = document.change_profile.copie.value;
		var sconto = document.change_profile.sconto.value;
		if (copie == "") {
        	alert("Il campo copie è obbligatorio.");
           	document.change_profile.copie.focus();
           	return false;
      	}
   		else if(copie < 0) {
           	alert("Il numero di copie deve essere compreso tra 0 e 100.");
           	document.change_profile.copie.focus();
           	return false;
      	}
      	else if(isNaN(parseInt(copie))) {
      	  	alert("Inserisci un numero valido");
      	  	document.change_profile.copie.focus();
      	  	return false;
     	}
     	else if(isNaN(parseInt(sconto))) {
      	  	alert("Inserisci un numero valido");
      	  	document.change_profile.sconto.focus();
      	  	return false;
     	}
   		else if (sconto == "") {
           	alert("Il campo sconto è obbligatorio.");
           	document.change_profile.sconto.focus();
           	return false;
   		}
   		else if (sconto < 0 || sconto > 100) {
			alert("Lo sconto deve essere compreso tra 0 e 100.");
           	document.change_profile.sconto.focus();
           	return false;
     	}
      	else {
           	document.change_profile.submit();
      	}
  	}
</script>
<body>
	<?php
		session_start();
		if(!(isset($_SESSION['email']))) {
			header('Location:/login.php');
		}
		else if(isset($_POST['modifica'])) {
			$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
			$result=$client->editLibroVenditore(array($_SESSION['email'],$_POST['sconto'],$_POST['copie'],$_POST['ISBN']));
			if($result->return==0) {
				header('Location:/modificaLibro.php?update=ok&ISBN='.$_POST['ISBN']);/*libro.php?update=ok*/
			}
			else if($result->return==-1) {
				echo '<div class="error">Errore generico</div>';
				echo '<form name="back" action="/modificaLibro.php?ISBN='.$_POST['ISBN'].'" method="POST">';
				echo '<input type="submit" name="back" value="Torna alla modifica"/>';
				echo '</form>';				
			}
		}
		else { ?>
            <div id="contenitoreGrande" class="page_settings_profile">
                <!-- START HEADER -->
                <div id="dashboard">
                    <ul>
                        <li>
                            <a href="/cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
            				$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
                            $nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="/logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2">
                    <div id="logo" class="">
                        <span><a href="/index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="/index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="/libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="/profiloLibreria.php"><span>Profilo</span></a>
                           </li>
                        </ul>
                    </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
				<?php
                    if(isset($_GET['update'])){
                        echo '<div class="success">Dati aggiornati correttamente!</div><br/><br/>';
                        unset($_GET['update']);
                    }
                    $result=$client->leggiScontoCopie(array("ISBN"=>$_GET['ISBN']));
                ?>
                <div id="contenitorePiccolo">
                    <div id="content">
                        <div id="page_head">
                            <span id="modLibro">Modifica il libro <?php echo $result->return['0'] ?></span>
                        </div>
                        <form id="change_profile" name="change_profile" class="standard_form" action="/modificaLibro.php" method="post">
                            <h4>
                                <label for="copie">
                                    <span>Copie</span>
                                </label>
                            </h4>
                            <div id="copie_div" class="input_wrap">
                                <h6>Inserisci il numero di copie disponibili</h6>
                                <?php
                                    echo '<input type="text" value="'.$result->return[2].'" id="copie" class="text_input" name="copie" size="30" maxlength="255" />';
                                ?>
                            </div>
                            <h4>
                                <label for="sconto">
                                    <span>Sconto</span>
                                </label>
                            </h4>
                            <h6 class="instruction">
                                <span>Cambia lo sconto: </span>
                            </h6>
                            <div id="sconto" class="input_wrap">
                                <?php
                                    echo '<input type="text" id="sconto" class="text_input" value="'.$result->return[1].'" name="sconto" size="30" maxlength="255" />';
                                ?>%
                            </div>
                            <input type="hidden" name="modifica" value="modifica"/>
                            <input type="hidden" name="ISBN" value="<?php echo $_GET['ISBN']?>"/>
                            <input type="button" style="margin-top:30px;" value="Invia modifiche" onClick="Check()"/>
                        </form>
                    </div>
                </div>
                <!-- END CONTENUTO -->       
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href="/relazione.php"> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href="/chisiamo.php"> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="mailto:progettosaed@mailinator.com?Subject=Informazioni" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
            </div> <?php
		}
	?>
</body>
</html>
