<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Modifica recensione</title>
    <link rel="stylesheet" type="text/css" href="/recensioniUtente.css" />
    <link rel="stylesheet" type="text/css" href="/footer.css" />
    <link rel="stylesheet" type="text/css" href="/messages.css" />
    <link rel="stylesheet" type="text/css" href="/header_logo.css" />
</head>
<script>
	function Check() {
		var testo = document.modificaRecensione.testo.value;
		if ((testo == "") || (testo == "undefined")) {
			alert("Il campo testo è obbligatorio.");
			document.change_profile.testo.focus();
			return false;
		}
		else {
		   document.modificaRecensione.submit();
		}
  	}
</script>
<body>
	<?php
		session_start();
		if(!(isset($_SESSION['username']))) {
			header('Location:/login.php');
		}
		else {?> 
			<div id="contenitoreGrande" class="page_settings_profile">
                <!-- START HEADER -->
                <div id="dashboard">
                    <ul>
                        <li>
                            <a href="/cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options">
                            <strong>Ciao, <?php echo $_SESSION['username'];?></strong>
                            |
                            <a href="/logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2">
                    <div id="logo" class="">
                        <span><a href="/index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="/index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="/recensioniUtente.php"><span>Le mie recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="/profiloUser.php"><span>Profilo</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
               <?php
					$client=new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
					if (isset($_POST['update'])){
						$parametri=array("nickname"=>$_SESSION['username'],"ISBN"=>$_POST['ISBN'],"corpo"=>$_POST['testo']);
						$result2=$client->modificaRecensione($parametri);
						if ($result2->return!=0){ /* Insuccesso della funzione */
							/*usando l'array post qui, evitiamo altre chiamate soap per leggere di nuovo i dati, nel caso di errori*/
							echo '<div class="error">Errore nella modifica della recensione. Ripeti l\'operazione se lo vuoi.</div><br/><br/>';
							echo 'Recensione del libro: '.$result['0'].'<br/>';
							echo '<form name="modificaRecensione" action="modificaRecensione.php" method="POST">';
							echo '<input type="text" name ="testo" value="'.$_POST['testo'].'"/><br/>';
							echo '<input type="hidden" name="ISBN" value="'.$_POST['ISBN'].'"/>';
							echo '<input type="hidden" name="update" value="update"/>';
							echo '<input type="submit" value="Invia"/><br>';
							echo '<a href="/recensioniUtente.php">Torna alle recensioni!</a>';
							echo '</form>';
						}
						else { /* Successo della modifica quando ==0*/
							unset($_POST['update']);
							header("Location:/recensioniUtente.php");
						}
					}
					else {
						$ISBN=$_GET['ISBN'];
						$parametri=array("nickname"=>$_SESSION['username'],"isbn"=>$ISBN);
						$result=$client->leggiRecensione($parametri);
						echo '<div class="testo">';
						echo '<h3 id="title">Recensione del libro: '.$result->return['0'].'</h3><br/>';
						echo '<form name="modificaRecensione" action="modificaRecensione.php" method="POST">';
						echo '<textarea name="testo" class="testo" cols="30" rows="10">'.$result->return['1'].'</textarea>';
						echo '<input type="hidden" name="update" value="update"/>';
						echo '<input type="hidden" name="ISBN" value="'.$ISBN.'"/>';
						echo '<input type="button" value="Invia modifiche" onClick="Check()"/>';
						echo '</form>';
						echo '<a href="/recensioniUtente.php" class=testo">Torna alle recensioni!</a>';
						echo '</div>';
					}
				?>
                <!-- END CONTENUTO -->
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href="/relazione.php"> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href="/chisiamo.php"> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="mailto:progettosaed@mailinator.com?Subject=Informazioni" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
    		</div><?php
		}
	?>
</body>
</html>
