<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="libriLibreria.css" />
</head>
<!-- Ci sono alcuni commenti all'interno del codice.
Tutto molto semplice e fa in sostanza la stessa cosa di recensioniUtente.php; qua stampa invece i libri di quella libreria.
Decidiamo se attivare i link del libro; se si bisogna fare le riche con il metodo get, così inseriamo direttamente il link
nei tag <a> del libro(facciamo una concatenazione tra 'parte-iniziale-default'.$result['titolo']. Il problema da risolvere 
sono gli spazi che ci possono essere nel nome. Dobbiamo trovare il modo di risolvere sto problema: eliminandoli o mettendoci delle 
'%'. 
IMPORTANTE: i bottoni modifica e cancella devono essere implementati ancora. -->
<body>
	<?php
		session_start();
		if(!(isset($_SESSION['email']))) {
			header('Location:login.php');
		}
		else {?>
            <div id="contenitoreGrande" class="page_settings_profile">
                <!-- START HEADER -->
                <div id="dashboard">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
							$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email'])); /* Lo mettiamo un controllo su cosa restituisce?*/
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
                <div id="contenitorePiccolo">
                    <div id="content">
                        <div id="titolo_content">
                            <h3>I miei libri</h3>
                            <h6>Qua sono visualizzate tutti i libri presenti nella mia lista</h6>
                        </div>
                        <?php
						  	$result=$client->ricercaLibriLibreria2(array('nomeLibreria'=>$nomeLibreria->return));
							if($result->return=='') {?>
                            	<div id="error_lista_libro"><?php
									echo 'Nessun libro da visualizzare';?>
                                </div><?php
							}
							else {
								?>
                                <table> 
									<?php
										for($i=0;$i< count($result->return);$i++) {?>
											<tr>
												<td>
													<a id="cover_libro" href="#"><span>Cover</span></a>
												</td>
												<td>
													<ul>
														<li>
                                          	<span style="font-style:italic;">
																<?php
																	echo $result->return[$i]->array[0]; //titolo
																?>
                                          	</span>
                                          	</span>
                                      		</li>
                                      		<li>
                                          	<span style="font-style:italic;">
                                          		<?php //isbn
                                          			echo '<a href="books/'.$result->return[$i]->array[1].'">';
																	echo $result->return[$i]->array[1];
																	echo '</a>';
																?>																
                                          	</span>
                                      		</li>
                                          <!-- Il link lo possiamo mandare ad una pagina dove ci sono tutti i libri
                                          dell'autore -->
														<li>
															<span style="font-style:italic;">
																<?php //autore
																	echo '<a href="autore/'.$result->return[$i]->array[2].'">';
																	echo $result->return[$i]->array[2];
																	echo '</a>';
																?>																
															</span>
														</li>
                                          <!-- Il link lo possiamo mandare ad una pagina dove ci sono tutti i libri
                                          di quell'editore -->
														<li>
															<span style="font-style:italic;">
																<?php //editore
																	$temp=str_replace(' ', '+', $result->return[$i]->array[3]);
																	echo '<a href="cerca.php?cerca_input='.$temp.'">';
																	echo $result->return[$i]->array[3];
																	echo '</a>';
																?>			
															</span>
                                      		</li>
														<li><span>Prezzo: <?php echo '<a href="ricercaAvanzata.php?search_side_text='.$result->return[$i]->array[4].'&search_side_select=Prezzo&search_side_submit=Cerca">'.$result->return[$i]->array[4].'</a>';?> </span></li>
														<li><span>Lingua: <?php echo '<a href="ricercaAvanzata.php?search_side_text='.$result->return[$i]->array[5].'&search_side_select=Lingua&search_side_submit=Cerca">'.$result->return[$i]->array[5].'</a>';?></span></li>														
														<li><span>Sconto: <?php echo $result->return[$i]->array[6]?></span></li>
														<li><span>Numero copie: <?php echo $result->return[$i]->array[7]?></span></li>
													</ul>
												</td>
												<td id="bottoni">
                                      	<?php
														$linkMod='modifica/libro/'.$result->return[$i]->array[1];
														print '<a href="'.$linkMod.'">Modifica</a>';
													?>
                                       <br />
                                       <?php
														$linkCanc="cancella/libro/".$result->return[$i]->array[1];
														print '<a href="'.$linkCanc.'">Cancella</a>';
													?>
												</td>
											</tr><?php
										}
									?>
                        		</table>
                            <?php
							}
							?>
                        
                    </div>
                </div>
                <!-- END CONTENUTO -->
                <!-- START FOOTER -->
                <div id="footer">
                    <ul id="links_footer">
                        <li class="item_footer">
                            <a href=""> Il nostro progetto</a>
                        </li>
                        <li class="item_footer">
                            <a href=""> Chi siamo?</a>
                        </li>
                        <li class="item_footer">
                            <a href="" class="last"> Contattaci</a>
                        </li>
                    </ul>
                </div>
                <!-- END FOOTER -->
            </div><?php
		}
	?>
</body>
</html>