<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ricerca avanzata</title>
    <link rel="stylesheet" type="text/css" href="ricercaAvanzata.css" />
    <link rel="stylesheet" type="text/css" href="messages.css" />
</head>
<script>
	function Check() {
		var anno = document.search_product_advance.search_year.value;
		var prezzo = document.search_product_advance.search_prize.value;
		if (isNaN(parseInt(prezzo))) {
			alert("Il prezzo deve essere un numero.");
			document.search_product_advance.prezzo.focus();
			return false;
		}
		else if (prezzo<0)) {
			alert("Il prezzo deve essere maggiore di zero.");
			document.search_product_advance.prezzo.focus();
			return false;
		}
		else if (anno < 0) {
			alert("L'anno deve essere maggiore di 0.");
			document.change_profile.editore.focus();
			return false;
		}
		else {
			document.search_product_advance.submit();
		}
	}
</script>
<!--
Bisogna sistemare la sidebar per bene: tipo allineare a sinistra, flottare a destra accanto alla ricerca avanzata, e restringere il div side, perché così va sopra al div della ricerca avanzata.
Bisogna aggiungere su Java una funzione di ricerca che prende un array di dimensione massimo 8 e fa la ricerca nella tabella dei libri
prendendo in considerazione ogni campo specificato nella ricerca avanzata.
Bisogna sistemare la stampa dei contenuti. Sembra che si sovrapponga alla ricerca avanzata, o ci vada vicino. Urge allontanarlo.
Inoltre bisogna capire perché da il div "advsearch_result" come se fosse separato dalla form della ricerca avanzata( fa un rettangolo da solo senza nulla dentro). FORSE QUEST'ULTIMO L'HO RISOLTO.
-->
<body>
	<?php 
		session_start();
	?>
    <div id="contenitore">
        <!-- START HEADER --><?php
        if(isset($_SESSION['username']) || isset($_SESSION['email'])) {
            if(isset($_SESSION['username'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
                            $username=$_SESSION['username'];
                            echo '<strong>Ciao, '.$username.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                           </li>
                           <li id="tab_B">
                            <a href="recensioniUtente.php"><span>La mia recensioni</span></a>
                           </li>
                           <li id="tab_C">
                                <a href="profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                    </div>
                </div><?php
            }
            else if(isset($_SESSION['email'])) { ?>
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
                            $nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">   
                        <ul id="main_menu">
                            <li id="tab_A">
                                <a href="index.php"><span>Pagina iniziale</span></a>
                           </li>
                           <li id="tab_B">
                            <a href="libriLibreria.php"><span>I miei libri</span></a>
                           </li>
                           <li id="tab_C">
                                <a href="profiloLibreria.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                    </div>
                </div>
        <?php
            }
        }
        else {?>
            <div id="header">
                <div id="header_logo">
                    <a href="index.php">La disoccupazione ti ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                </div>
                <div id="login">
                    <div id="botton_login">
                        <a href="login.php">Login</a>
                        |
                        <a href="iscrizioneUser.php">Iscriviti</a>
                        |
                        <a href="iscrizioneLibreria.php">Libreria</a>
                    </div>
                </div>
                <div id="scritta">
                    <h3 id="slogan">Anarchia.</h3>
                </div>
            </div><?php
        }?>
        <!-- END HEADER -->
        <!-- START CERCA -->
		<div id="contenitorePiccolo">
        	<div id="advsearch_result">
            	<form id="search_product_advance" class="standard_form" name="search_product_advance" action="ricercaAvanzata.php" method="get">
                    <dl>
                        <dd>
                            <h3>
                                <label for="advanced_search"><span>Ricerca avanzata</span></label>
                            </h3>
                            <br />
                            <div class="label">
								<h4>
                                    <label for="search_title"><span>Titolo:</span></label>
                                </h4>
                            </div>
                            <input type="text" id="search_title" class="text_input" name="search_title" value="" /> 
                            <br />
                            <div class="label">
                                <h4>
                                    <label for="search_author"><span>Autore:</span></label>
                                </h4>
                            </div>
                            <input type="text" id="search_author" class="text_input" name="search_author" value="" /> 
                            <br />
                            <div class="label">
                                <h4>
                                    <label for="search_ISBN"><span>ISBN:</span></label>
                                 </h4>
                            </div>
                            <input type="text" id="search_ISBN" class="text_input" name="search_ISBN" value="" /> 
                            <br />
                            <div class="label">
                                <h4>
                                    <label for="search_publisher"><span>Editore:</span></label>
                                </h4>
                            </div>
                            <input type="text" id="search_publisher" class="text_input" name="search_publisher" value="" />
                            <br />
                            <div class="label">
                                <h4>
                                    <label for="search_year"><span>Anno:</span></label>
                                </h4>
                            </div>
                            <input type="text" id="search_year" class="text_input" name="search_year" value="" />
                            <br />
                            <div class="label">
                                <h4>
                                    <label for="search_vote"><span>Voto:</span></label>
                                </h4>
                            </div>
                            <input type="text" id="search_vote" class="text_input" name="search_vote" value="" />
                            <br />
                            <div class="label">
                                <h4>
                                    <label for="search_languages"><span>Lingua:</span></label>
                                </h4>
                            </div>
                            <input type="text" id="search_languages" class="text_input" name="search_languages" value="" />
                            <br />
                            <div class="label">
                                <h4>
                                    <label for="search_prize"><span>Prezzo:</span></label>
                                </h4>
                            </div>
                            <input type="text" id="search_prize" class="text_input" name="search_prize" value="" />
                            <!--<input type="submit" id="searchAdvance" name="searchAdvance" value="Cerca" />-->
                            <input type="button" id="searchAdvance" value="Cerca" name="searchAdvance" onClick="Check()"/>
                        </dd>
                     </dl>
           		</form>
  			</div>
            <!-- END CERCA -->
            <!-- START SIDE -->
            <div id="side">
            	<form id="search_side" name="search_side" action="ricercaAvanzata.php" method="get">
                	<h3>
                		<label id="search_side_label">Cerca per:</label>
                    </h3>
                    <br />
                   	<input type="text" name="search_side_text" id="search_side_text" value=""  />
                    <select id="search_side_select" name="search_side_select">
                    	<option id="search_side_titolo" class="search_side_options" value="Titolo">Titolo</option>
                        <option id="search_side_autore" class="search_side_options" value="Autore">Autore</option>
                        <option id="search_side_isbn" class="search_side_options" value="ISBN">ISBN</option>
                        <option id="search_side_casa_editrice" class="search_side_options" value="Editore">Editore</option>
                        <option id="search_side_anno" class="search_side_options" value="Anno">Anno</option>
                        <option id="search_side_lingua" class="search_side_options" value="Lingua">Lingua</option>
                        <option id="search_side_prezzo" class="search_side_options" value="Prezzo">Prezzo</option>               
                        <option id="search_side_voto" class="search_side_options" value="Voto">Voto</option>                 
                 	</select>
                    <input type="submit" id="search_side_submit" name="search_side_submit" value="Cerca"  />
                </form>
            </div>
            <!-- END SIDE -->
            <?php
            $client=new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
				if(isset($_GET['search_side_text'])) {
					$campo=array('campo'=>$_GET['search_side_text']);
					if($_GET['search_side_select']=='Titolo') {
						$result=$client->ricercaTitolo($campo);
					}
					if($_GET['search_side_select']=='Autore') {
						$result=$client->ricercaAutore($campo);
					}
					if($_GET['search_side_select']=='ISBN') {
						$result=$client->ricercaISBN($campo);
					}
					if($_GET['search_side_select']=='Editore') {
						$result=$client->ricercaCasaEditrice($campo);
					}
					if($_GET['search_side_select']=='Anno') {
						$result=$client->ricercaAnno($campo);
					}
					if($_GET['search_side_select']=='Lingua') {
						$result=$client->ricercaLingua($campo);
					}
					if($_GET['search_side_select']=='Prezzo') {
						$result=$client->ricercaPrezzo($campo);
					}
					if($_GET['search_side_select']=='Voto') {
						$result=$client->ricercaVoto($campo);
					}
				}
			?>
       	<?php
            $parametro=array('','','','','','','','');
				if(isset($_GET['search_title'])) {
					$parametro=array(0=>$_GET['search_title']);
				}
				if(isset($_GET['search_author'])) {
					$parametro[1]=$_GET['search_author'];
				}
				if(isset($_GET['search_ISBN'])) {
					$parametro[2]=$_GET['search_ISBN'];
				}
				if(isset($_GET['search_publisher'])) {
					$parametro[3]=$_GET['search_publisher'];
				}
				if(isset($_GET['search_year'])) {
					$parametro[4]=$_GET['search_year'];
				}
				if(isset($_GET['search_vote'])) {
					$parametro[5]=$_GET['search_vote'];
				}
				if(isset($_GET['search_languages'])) {
					$parametro[6]=$_GET['search_languages'];
				}
				if(isset($_GET['search_prize'])) {
					$parametro[7]=$_GET['search_prize'];
				}
				if(isset($_GET['search_title'])|| isset($_GET['search_author'])|| isset($_GET['search_ISBN'])|| isset($_GET['search_publisher'])|| isset($_GET['search_year'])|| isset($_GET['search_vote'])|| isset($_GET['search_languages'])|| isset($_GET['search_prize'])) {				
					$result=$client->ricercaAvanzata($parametro);
				}				
			?>
            <div id="content">
                <div id="shelf_wrap" class="list_view"> 
                    <div class="shelf">
                        <table id="" class="">
                            <?php
								if(@$result->return[0]->array[0]=='') {
									echo '<span class="error">Nessun risultato per questa ricerca</error>';
								}
								else {
									$i=0;
									$j=0;
									$nLibri=count($result->return);
									for($i=0;$i<$nLibri;$i++) {?>
										<tr id="" title="">
											<td class="cover_wrap">
												<a class="cover_image" href="">
												<img border="1" src="" class="book_cover" width="500" 
														height="766" alt="" title="" /></a>
											</td>
											<td>
												<ul class="item_text">
													<?php
														for($j=0;$j<8;$j++) {
															if($j==0) { //Titolo libro
																print '<li class="title">'.$result->return[$i]->array[$j].'</li>';
															}
															if($j==1) { //Autore libro
																print '<li class="contributor"><span><a href="autore/'.$result->return[$i]->array[$j].'">'.$result->return[$i]->array[$j].'</a></span></li>';
															}
															if($j==4) { //ISBN libro
																print '<li class="meta"><span><a href="books/'.$result->return[$i]->array[$j].'">'.$result->return[$i]->array[$j].'</span></li>';
															}
														}
													?>
												</ul>
											</td>
										</tr> <?php
									}
								}
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href=""> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href=""> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
        <!-- END FOOTER -->
    </div>
</body>
</html>