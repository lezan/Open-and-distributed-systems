<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Modifica le informazioni del libro</title>
    <link rel="stylesheet" type="text/css" href="/libro.css" />
</head>
<script>
  function Check() {
	var titolo = document.change_profile.titolo.value;
	var autore = document.change_profile.autore.value;
	var editore = document.change_profile.casa_editrice.value;
	var anno = document.change_profile.anno.value;
	var prezzo = document.change_profile.prezzo.value;
	if (titolo == "") {
           alert("Il campo titolo è obbligatorio.");
           document.change_profile.titolo.focus();
           return false;
        }
	else if (autore == "") {
           alert("Il campo autore è obbligatorio.");
           document.change_profile.autore.focus();
           return false;
        }
	else if (editore == "") {
           alert("Il campo editore è obbligatorio.");
           document.change_profile.casa_editrice.focus();
           return false;
        }
	else if (anno == "") {
           alert("Il campo anno è obbligatorio.");
           document.change_profile.anno.focus();
           return false;
        }
	else if (prezzo == "") {
           alert("Il campo prezzo è obbligatorio.");
           document.change_profile.prezzo.focus();
           return false;
        }
        //INVIA IL MODULO
        else {
           document.change_profile.submit();
        }
  }
</script>
<body>
	<?php
		session_start();
		if(!(isset($_SESSION['email']))) {
			header('Location:/login.php');
		}
		else if(isset($_POST['modifica']))
		{
			$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
			$parametri=array($_SESSION['email'],$_POST['ISBN'],$_POST['titolo'],$_POST['autore'],$_POST['casa_editrice'],$_POST['anno'],$_POST['lingua'],$_POST['prezzo']);
			$result=$client->editLibroCatalogo($parametri);
				if($result->return==0) {
					header('Location:/modificaLibroCatalogo.php?update=ok&ISBN='.$_POST['ISBN']);/*libro.php?update=ok*/
				}
				else if($result->return==-1) {
					echo 'Errore generico';
					echo '<form name="back" action="/modificaLibroCatalogo.php?ISBN='.$_POST['ISBN'].'" method="POST">';
					echo '<input type="submit" name="back" value="Torna alla modifica"/>';
					echo '</form>';				
				}
		}
		else { ?>
                <div id="contenitoreGrande" class="page_settings_profile">
                    <!-- START HEADER -->
                    <div id="dashboard">
                        <ul>
                            <li>
                                <a href="/cerca.php" title="cerca">Cerca il libro</a>
                            </li>
                            <li id="dashboard_options"><?php
                                echo '<strong>Ciao, '.$_SESSION['email'].'</strong>'; ?>
                                |
                                <a href="/logout.php" title="Esci"><span>Esci</span></a> 
                            </li>
                        </ul>
                    </div>
                    <div id="header2">
                        <div id="logo" class="">
                            <span><a href="/index.php" title="Logo | Home">Logo</a></span> 
                        </div>
                        <div id="menus">   
                            <ul id="main_menu">
                                <li id="tab_A">
                                    <a href="/index.php"><span>Pagina iniziale</span></a>
                                </li>
                                <li id="tab_B">
                                    <a href="/libriLibreria.php"><span>I miei libri</span></a>
                                </li>
                                <li id="tab_C">
                                    <a href="/profiloLibreria.php"><span>Profilo</span></a>
                               </li>
                            </ul>
                        </div>
                    </div>
                    <!-- END HEADER -->
                    <!-- START CONTENUTO -->
			<?php
				if(isset($_GET['update'])){
					echo 'Dati aggiornati correttamente!<br/><br/>';
					unset($_GET['update']);
				}
				$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
				$result=$client->leggiLibro(array("isbn"=>$_GET['ISBN']));
			?>
                    <div id="contenitorePiccolo">
                        <div id="content">
                            <div id="page_head">
                                <span>Modifica il libro <?php echo $result->return['0'] ?></span>
                            </div>
                            <form id="change_profile" name="change_profile" class="standard_form" action="/modificaLibroCatalogo.php" method="post">
                                <h4>
                                    <label for="titolo">
                                        <span>Titolo</span>
                                    </label>
                                </h4>
                                <div id="titolo_div" class="input_wrap">
                                    <h6>Inserisci il nuovo titolo</h6>
                                    <?php
                                        echo '<input type="text" value="'.$result->return[0].'" id="titolo" class="text_input" name="titolo" size="30" maxlength="255" />';
                                    ?>
                                </div>
                                <h4>
                                    <label for="autore">
                                        <span>Autore</span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Cambia l'autore: </span>
                                </h6>
                                <div id="autore" class="input_wrap">
                                    <?php
                                        echo '<input type="text" id="autore" class="text_input" value="'.$result->return[1].'" name="autore" size="30" maxlength="255" />';
                                    ?>
                                </div>
				<h4>
                                    <label for="casa_editrice">
                                        <span>Casa editrice</span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Cambia la casa editrice: </span>
                                </h6>
                                <div id="autore" class="input_wrap">
                                    <?php
                                        echo '<input type="text" id="casa_editrice" class="text_input" value="'.$result->return[2].'" name="casa_editrice" size="30" maxlength="255" />';
                                    ?>
                                </div>
                                <h4>
                                    <label for="anno">
                                        <span>Anno: </span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Inserisci l'anno di pubblicazione</span>
                                </h6>
                                <div id="anno" class="input_wrap">
                                    <?php
                                        echo '<input type="text" id="anno" class="text_input" name="anno" value="'.$result->return[3].'" size="30" maxlength="4" min="4"/>';
                                    ?>
                                </div>
                                <h4>
                                    <label for="prezzo">
                                        <span>Prezzo</span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Inserisci il prezzo di listino</span>
                                </h6>
                                <div id="prezzo" class="input_wrap">
                                    <?php
                                        echo '<input type="text" id="prezzo" class="text_input" name="prezzo" value="'.$result->return[4].'" size="30" maxlength="255" />';
                                    ?>
                                </div>
                                <div id="lingua">                    	
                                    <h4>
                                        <label for="lingua">
                                            <span>Lingua: </span>
                                        </label>
                                    </h4>
                                    <h6 class="instruction">
                                        <span>Inserisci la lingua del libro</span>
                                    </h6>
                                    <div id="lingua_div" class="input_wrap">
                                        <?php
                                            echo '<input type="text" id="lingua" class="text_input" name="lingua" value="'.$result->return[5].'" size="30" maxlength="150" />';
                                        ?>
                                    </div>
                                </div>
				<input type="hidden" name="modifica" value="modifica"/>
				<input type="hidden" name="ISBN" value="<?php echo $_GET['ISBN']?>"/>
				<!--<input type="submit" name="submit" value="Modifica i dati del libro"/>-->
				<input type="button" value="Aggiungi il libro" onClick="Check()"/>
                            </form>
                        </div>
                    </div>
                    <!-- END CONTENUTO -->       
                    <!-- START FOOTER -->
                    <div id="footer">
                        <ul id="links_footer">
                            <li class="item_footer">
                                <a href=""> Il nostro progetto</a>
                            </li>
                            <li class="item_footer">
                                <a href=""> Chi siamo?</a>
                            </li>
                            <li class="item_footer">
                                <a href="" class="last"> Contattaci</a>
                            </li>
                        </ul>
                    </div>
                    <!-- END FOOTER -->
                </div><?php
			}
	?>
</body>
</html>
