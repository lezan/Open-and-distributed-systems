<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="/libro.css" />
</head>

<body>
	<?php 
		session_start();
		function getUrl() {
 			return substr($_SERVER["QUERY_STRING"],strrpos($_SERVER["QUERY_STRING"],"=")+1);
		}
		$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
		$isbn=getUrl();
		$checkISBN=$client->ricercaISBN(array('campo'=>$isbn));
		if($checkISBN->return[0]=='') {
	?>
	<div id="contenitoreGrande" class="page_settings_profile">
		Libro non presente
	</div>
	<?php	
		}
		else {
		$autore=$client->leggiAutore(array('isbn'=>$isbn));
		$titolo=$client->leggiTitolo(array('isbn'=>$isbn));
	?>
    <div id="contenitoreGrande" class="page_settings_profile">
        <?php
        if(isset($_SESSION['username']) || isset($_SESSION['email'])) {
            if(isset($_SESSION['username'])) { ?>
            	<!-- START HEADER -->
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="/cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
                            echo '<strong>Ciao, '.$_SESSION['username'].'</strong>'; ?>
                            |
                            <a href="/logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="/index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="/index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="/recensioniUtente.php"><span>La mia recensioni</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="/profiloUser.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                     </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
				<div id="contenitorePiccolo">
                    <div id="content">
                        <div id="product_info">
                            <div class="cover">
                                <img src="" />
                            </div>                     
                            <div class="info">
                                <h1 class="title"><?php echo $titolo->return ?></h1>
                                <p class="contributor">
                                    <span>Di 
                                			<?php
                                				echo '<a href="/autore/'.$autore->return.'">'.$autore->return.'</a>'
                                			?>
                                		</span>
                                    <!-- Decidiamo se mettere il link sull'autore. In cas
                                    affermativo, lo manderemo ad una pagina tipo libro.php in cui vengono mostrati solo i libri di 
                                    quell'autore, quindi una ricerca per autore printata sulla pagina. 
                                    Non è difficile da fare, ed abbiamo già il layout praticamente pronto, dato che lo possiamo 
                                    prendere da libro.php -->
                                </p>
                            </div>
                        </div>
                        <div id="tab_content">
                            <div id="product_reviews">
                                <h2 class="section_heading">
                                    <strong>
                                        <span>
                                        	<?php
												$nRecensioni=$client->leggiNumeroRecensioni(array('isbn'=>$isbn));
												echo $nRecensioni->return;
											?>
                                            recensioni
                                        </span><?php
                                   echo '</strong><a class="btn_action float_right" id="write_review_btn" style="cursor:pointer;" href="/aggiungi/recensione/'.$isbn.'">Scrivi una recensione</a>';
											?>                                
                                </h2>
                                	<?php
										if($nRecensioni->return==0) {
											echo '<div id="no_found_comments"> Non ci sono recensioni disponibili per questo libro</div>';
										}
										else {
											$recensioni=$client->leggiRecensioniLibro(array('isbn'=>$isbn));
											if($recensioni->return=='') {
												echo '<div id="no_found_comments"> Non ci sono recensioni disponibili per questo libro</div>';
											}
											else {
												for($i=0;$i<$nRecensioni->return;$i++) {
													print '<ul id="'.$recensioni->return[$i]->array[2].'" class="comment_block">' ?>
														<li id="">
															<div class="comment_entry">
																<div class="comment_entry_inner">
																	<div class="comment_entry_content">
																		<div class="comment_full hide">
																			<p>
																				<?php
																					echo $recensioni->return[$i]->array[0];
																				?>
																			</p>
																		</div>
																	</div>
																</div>
															</div>
															<p class="comment_details">
																<a href="" class="buddy_icon_wrap">
																	<img height="24" width="24" src=""><!-- Immagine profilo utente-->
																</a>
																<a href="">
                                                                	<?php
																		echo $recensioni->return[$i]->array[3];
																	?>
                                                                </a> <!-- Link al profilo dell'utente che ha fatto il commento -->
																<span>
                                                                	<?php
																		echo $recensioni->return[$i]->array[1];
																	?>
                                                                </span>
															</p>
														</li>
													</ul><?php
												}
											}
										}
									?>
                            </div>
                            <!-- Forse bisogna lasciare soltanto il voto, dato che gli altri cambiano a seconda di chi lo vende -->
                            <div id="product_details">
                            	<?php
                            		if(isset($_POST['select_vota_libro'])) {
												$vota=$client->votaLibro(array('ISBN'=>$isbn,'voto'=>$_POST['select_vota_libro'],'nickname'=>$_SESSION['username']));
											}
								?>
                                <h2 class="section_heading">
                                    <strong><span>Dettagli Libro</span></strong>
                                    <div id="vota">
                                    	<?php
                                    		echo '<form action="'.$_SERVER["REQUEST_URI"].'" name="vota_libro" id="vota_libro" method="post" >';
                                    	?>                                       
                                            <label>
                                                Vota:
                                            </label>
                                            <select name="select_vota_libro" id="select_vota_libro" onchange="document.vota_libro.submit();">
                                                <option value="" selected="selected">- -</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                            </select>
                                            <!-- <input type="submit" id="vota_submit" name="vota_submit" value="Cerca"  />-->
                                        </form>
                                    </div>           
                                </h2>
                                <ul class="details">
                                    <li>
                                        <span>
                                            <span>Voto</span>:
											<?php
												$voto=$client->leggiVoto(array('isbn'=>$isbn));
												echo $voto->return;
											?>
                                            (
                                            <?php
												$votoUtente=$client->leggiVotoUtente(array('isbn'=>$isbn,'nickname'=>$_SESSION['username']));
												echo $votoUtente->return;
											?>
                                            )
                                        </span>
                                    </li>
                                    <li>
                                    	<span>ISBN:</span>
                                       	<strong>
                                       	<?php
											echo $isbn;
									   	?>
                                       	</strong>
                                    </li>
                                    <li>
                                        <span>
                                            <span>Editore</span>:
                                        </span>
                                       	<strong>
                                        	<?php
												$editore=$client->leggiEditore(array('isbn'=>$isbn));
												echo $editore->return;
											?>
                                       	</strong>
                                    </li>
                                    <li>
                                        <span>
                                            <span>Data di pubblicazione</span>:
                                        </span>
                                        <strong>
                                        	<?php
												$data=$client->leggiDataPubblicazione(array('isbn'=>$isbn));
												echo $data->return;
											?>
                                        </strong>
                                    </li>
                                    <li>
                                        <span>
                                            <span>Lingua:</span>
                                        </span>
                                        <strong>
                                        	<?php
												$lingua=$client->leggiLingua(array('isbn'=>$isbn));
												echo $lingua->return;
											?>
                                        </strong>
                                    </li>
                                </ul>
                            </div>
                            <div id="product_prices">
                                <h2 class="section_heading">
        
                                    <strong>
                                        <span>Prezzi</span> 
                                    </strong>
                                </h2>
                                <!-- Qua ci printiamo tutte le librerie che hanno questo libro -->
                                <table class="price_table">
                                	<tr>
                                    	<th><span>ISBN</span></th>
                                        <th><span>Editore</span></th>
                                        <th><span>Prezzo</span></th>
                                        <th><span>Venditore</span></th>
                                        <th><span>Copie</span></th>
                                        <th><span>Sconto</span></th>
                                    </tr>
                                	<?php
										$venditori=array();
										$venditori=$client->leggiLibroVenditore(array('isbn'=>$isbn));
										if($venditori->return=='') {?>
                                        	<tr class="">
                                        		<td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                            </tr><?php
										}
										else {
											for($i=0;$i< count($venditori->return);$i++) {?>
                                                <tr class="">
                                                    <td class="current"><?php echo $isbn ?></td>
                                                    <td class="current"><?php echo $editore->return ?></td>
                                                    <td class="current">
														<?php
                                                        	$prezzo=$client->leggiPrezzo(array('isbn'=>$isbn));
															echo $prezzo->return; 
														?>
                                                    </td>
                                                    <td class="current"><?php echo '<a href="/libreria/'.$venditori->return[$i]->array[0].'">'.$venditori->return[$i]->array[0].'</a>'; ?></td>
                                                    <td class="current"><?php $venditori->return[$i]->array[2] ?></td>
                                                    <td class="current"><?php echo $venditori->return[$i]->array[1] ?>%</td>
                                                </tr><?php
											}
										}
									?>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- END CONTENUTO -->
                    <!-- START SIDE -->
                    <div id="side">
                        <div id="acquista">
                            <h3>Sei interessato a questo libro? <br />Acquistalo ora.</h3>
                            <a href="">Aggiungi al carrello.</a>
                        </div>
                    </div>
                    <!-- END SIDE -->
                </div><?php
            }
            else if(isset($_SESSION['email'])) { ?>
            	<!-- START HEADER -->
                <div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="/cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="/logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="/index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="/index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="/libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="/profiloLibreria.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                       </div>
                </div>
                <!-- END HEADER -->
                <!-- START CONTENUTO -->
				<div id="contenitorePiccolo">
                    <div id="content">
                        <div id="product_info">
                            <div class="cover">
                                <img src="" />
                            </div>                     
                            <div class="info">
                                <h1 class="title"><?php echo $titolo->return ?></h1>
                                <p class="contributor">
                                    <span>Di 
                                			<?php
                                				echo '<a href="/autore/'.$autore->return.'">'.$autore->return.'</a>'
                                			?>
                                		</span> <!-- Decidiamo se mettere il link sull'autore. In cas
                                    affermativo, lo manderemo ad una pagina tipo libro.php in cui vengono mostrati solo i libri di 
                                    quell'autore, quindi una ricerca per autore printata sulla pagina. 
                                    Non è difficile da fare, ed abbiamo già il layout praticamente pronto, dato che lo possiamo 
                                    prendere da libro.php -->
                                </p>
                            </div>
                        </div>
                        <div id="tab_content">
                            <div id="product_reviews">
                                <h2 class="section_heading">
                                    <strong>
                                        <span>
                                        	<?php
												$nRecensioni=$client->leggiNumeroRecensioni(array('isbn'=>$isbn));
												echo $nRecensioni->return;
											?>
                                            recensioni
                                        </span>
                                    </strong>
                                </h2>
                                	<?php
										if($nRecensioni->return==0) {
											echo '<div id="no_found_comments"> Non ci sono recensioni disponibili per questo libro</div>';
										}
										else {
											$recensioni=$client->leggiRecensioniLibro(array('isbn'=>$isbn));
											if($recensioni->return=='') {
												echo '<div id="no_found_comments"> Non ci sono recensioni disponibili per questo libro</div>';
											}
											else {
												for($i=0;$i< count($recensioni->return);$i++) {
													print '<ul id="'.$recensioni->return[$i]->array[2].'" class="comment_block">' ?>
														<li id="">
															<div class="comment_entry">
																<div class="comment_entry_inner">
																	<div class="comment_entry_content">
																		<div class="comment_full hide">
																			<p>
																				<?php
																					echo $recensioni->return[$i]->array[0];
																				?>
																			</p>
																		</div>
																	</div>
																</div>
															</div>
															<p class="comment_details">
																<a href="" class="buddy_icon_wrap">
																	<img height="24" width="24" src=""><!-- Immagine profilo utente-->
																</a>
																<a href="">
                                                                	<?php
																		echo $recensioni->return[$i]->array[3];
																	?>
                                                                </a> <!-- Link al profilo dell'utente che ha fatto il commento -->
																<span>
                                                                	<?php
																		echo $recensioni->return[$i]->array[1];
																	?>
                                                                </span>
															</p>
														</li>
													</ul><?php
												}
											}
										}
									?>
                            </div>
                            <!-- Forse bisogna lasciare soltanto il voto, dato che gli altri cambiano a seconda di chi lo vende -->
                            <div id="product_details">
                                <h2 class="section_heading">
                                    <strong><span>Dettagli Libro</span></strong>
                                </h2>
                                <ul class="details">
                                    <li>
                                        <span>
                                            <span>Voto</span>:
											<?php
												$voto=$client->leggiVoto(array('isbn'=>$isbn));
												echo $voto->return;
											?>
                                        </span>
                                    </li>
                                    <li>
                                    	<span>ISBN:</span>
                                       	<strong>
                                       	<?php
											echo $isbn;
									   	?>
                                       	</strong>
                                    </li>
                                    <li>
                                        <span>
                                            <span>Editore</span>:
                                        </span>
                                       	<strong>
                                        	<?php
												$editore=$client->leggiEditore(array('isbn'=>$isbn));
												echo $editore->return;
											?>
                                       	</strong>
                                    </li>
                                    <li>
                                        <span>
                                            <span>Data di pubblicazione</span>:
                                        </span>
                                        <strong>
                                        	<?php
												$data=$client->leggiDataPubblicazione(array('isbn'=>$isbn));
												echo $data->return;
											?>
                                        </strong>
                                    </li>
                                    <li>
                                        <span>
                                            <span>Lingua:</span>
                                        </span>
                                        <strong>
                                        	<?php
												$lingua=$client->leggiLingua(array('isbn'=>$isbn));
												echo $lingua->return;
											?>
                                        </strong>
                                    </li>
                                </ul>
                            </div>
                            <div id="product_prices">
                                <h2 class="section_heading">
        
                                    <strong>
                                        <span>Prezzi</span> 
                                    </strong>
                                </h2>
                                <!-- Qua ci printiamo tutte le librerie che hanno questo libro -->
                                <table class="price_table">
                                	<tr>
                                    	<th><span>ISBN</span></th>
                                        <th><span>Editore</span></th>
                                        <th><span>Prezzo</span></th>
                                        <th><span>Venditore</span></th>
                                        <th><span>Copie</span></th>
                                        <th><span>Sconto</span></th>
                                    </tr>
                                	<?php
										$venditori=$client->leggiLibroVenditore(array('isbn'=>$isbn));
										if($venditori->return=='') {?>
                                        	<tr class="">
                                        		<td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                                <td class="current">--</td>
                                            </tr><?php
										}
										else {
											for($i=0;$i< count($venditori->return);$i++) {?>
                                                <tr class="">
                                                    <td class="current"><?php echo $isbn ?></td>
                                                    <td class="current"><?php echo $editore->return ?></td>
                                                    <td class="current">
														<?php
                                                        	$prezzo=$client->leggiPrezzo(array('isbn'=>$isbn));
															echo $prezzo->return; 
														?>
                                                    </td>
                                                    <td class="current"><?php echo '<a href="/libreria/'.$venditori->return[$i]->array[0].'">'.$venditori->return[$i]->array[0].'</a>'; ?></td>
                                                    <td class="current"><?php echo $venditori->return[$i]->array[2] ?></td>
                                                    <td class="current"><?php echo $venditori->return[$i]->array[1] ?>%</td>
                                                </tr><?php
											}
										}
									?>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- END CONTENUTO -->
                    <!-- START SIDE -->
                    <div id="side">
                	</div>
                    <!-- END SIDE -->
                </div><?php
            }
        }
        else {?>
        	<!-- START HEADER -->
            <div id="header">
                <div id="header_logo">
                    <a href="/index.php">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
                </div>
                <div id="login">
                    <div id="botton_login">
                        <a href="/login.php">Login</a>
                        |
                        <a href="/iscrizioneUser.php">Iscriviti</a>
                        |
                        <a href="/iscrizioneLibreria.php">Libreria</a>
                    </div>
                </div>
                <div id="scritta">
                    <h3 id="slogan">Anarchia.</h3>
                </div>
            </div>
            <!-- END HEADER -->
            <!-- START CONTENUTO -->
            <div id="contenitorePiccolo">
                <div id="content">
                    <div id="product_info">
                        <div class="cover">
                            <img src="" />
                        </div>                     
                        <div class="info">
                            <h1 class="title"><?php echo $titolo->return ?></h1>
                            <p class="contributor">
                                <span>Di 
                                		<?php
                                			echo '<a href="/autore/'.$autore->return.'">'.$autore->return.'</a>'
                                		?>
                                </span> <!-- Decidiamo se mettere il link sull'autore. In cas
                                affermativo, lo manderemo ad una pagina tipo libro.php in cui vengono mostrati solo i libri di 
                                quell'autore, quindi una ricerca per autore printata sulla pagina. 
                                Non è difficile da fare, ed abbiamo già il layout praticamente pronto, dato che lo possiamo 
                                prendere da libro.php -->
                            </p>
                        </div>
                    </div>
                    <div id="tab_content">
                        <div id="product_reviews">
                            <h2 class="section_heading">
                                <strong>
                                    <span>
                                        <?php
                                            $nRecensioni=$client->leggiNumeroRecensioni(array('isbn'=>$isbn));
                                            echo $nRecensioni->return;
                                        ?>
                                        recensioni
                                    </span>
                                </strong>
                            </h2>
                                <?php
                                    if($nRecensioni->return==0) {
                                        echo '<div id="no_found_comments"> Non ci sono recensioni disponibili per questo libro</div>';
                                    }
                                    else {
                                        $recensioni=$client->leggiRecensioniLibro(array('isbn'=>$isbn));
                                        if($recensioni->return[0]->array[0]=='') {
                                            echo '<div id="no_found_comments"> Non ci sono recensioni disponibili per questo libro</div>';
                                        }
                                        else {
                                            for($i=0;$i< count($recensioni->return);$i++){
                                                print '<ul id="'.$recensioni->return[$i]->array[2].'" class="comment_block">' ?>
                                                    <li id="">
                                                        <div class="comment_entry">
                                                            <div class="comment_entry_inner">
                                                                <div class="comment_entry_content">
                                                                    <div class="comment_full hide">
                                                                        <p>
                                                                            <?php
                                                                                echo $recensioni->return[$i]->array[0];
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <p class="comment_details">
                                                            <a href="" class="buddy_icon_wrap">
                                                                <img height="24" width="24" src=""><!-- Immagine profilo utente-->
                                                            </a>
                                                            <a href="">
                                                                <?php
                                                                    echo $recensioni->return[$i]->array[3];
                                                                ?>
                                                            </a> <!-- Link al profilo dell'utente che ha fatto il commento -->
                                                            , 
                                                            <span>
                                                                <?php
                                                                    echo $recensioni->return[$i]->array[1];
                                                                ?>
                                                            </span>
                                                        </p>
                                                    </li>
                                                </ul><?php
                                            }
                                        }
                                    }
                                ?>
                        </div>
                        <!-- Forse bisogna lasciare soltanto il voto, dato che gli altri cambiano a seconda di chi lo vende -->
                        <div id="product_details">
                            <h2 class="section_heading">
                                <strong><span>Dettagli Libro</span></strong>
                            </h2>
                            <ul class="details">
                                <li>
                                    <span>
                                        <span>Voto</span>:
                                        <?php
                                            $voto=$client->leggiVoto(array('isbn'=>$isbn));
                                            echo $voto->return;
                                        ?>
                                    </span>
                                </li>
                                <li>
                                    <span>ISBN:</span>
                                    <strong>
                                    <?php
                                        echo $isbn;
                                    ?>
                                    </strong>
                                </li>
                                <li>
                                    <span>
                                        <span>Editore</span>:
                                    </span>
                                    <strong>
                                        <?php
                                            $editore=$client->leggiEditore(array('isbn'=>$isbn));
                                            echo $editore->return;
                                        ?>
                                    </strong>
                                </li>
                                <li>
                                    <span>
                                        <span>Data di pubblicazione</span>:
                                    </span>
                                    <strong>
                                        <?php
                                            $data=$client->leggiDataPubblicazione(array('isbn'=>$isbn));
                                            echo $data->return;
                                        ?>
                                    </strong>
                                </li>
                                <li>
                                    <span>
                                        <span>Lingua:</span>
                                    </span>
                                    <strong>
                                        <?php
                                            $lingua=$client->leggiLingua(array('isbn'=>$isbn));
                                            echo $lingua->return;
                                        ?>
                                    </strong>
                                </li>
                            </ul>
                        </div>
                        <div id="product_prices">
                            <h2 class="section_heading">
    
                                <strong>
                                    <span>Prezzi</span> 
                                </strong>
                            </h2>
                            <!-- Qua ci printiamo tutte le librerie che hanno questo libro -->
                            <table class="price_table">
                                <tr>
                                    <th><span>ISBN</span></th>
                                    <th><span>Editore</span></th>
                                    <th><span>Prezzo</span></th>
                                    <th><span>Venditore</span></th>
                                    <th><span>Copie</span></th>
                                    <th><span>Sconto</span></th>
                                </tr>
                                <?php
                                    $venditori=$client->leggiLibroVenditore(array('isbn'=>$isbn));
                                    if($venditori->return=='') {?>
                                        <tr class="">
                                            <td class="current">--</td>
                                            <td class="current">--</td>
                                            <td class="current">--</td>
                                            <td class="current">--</td>
                                            <td class="current">--</td>
                                            <td class="current">--</td>
                                        </tr><?php
                                    }
                                    else {
                                        for($i=0;$i< count($venditori->return);$i++) {?>
                                            <tr class="">
                                                <td class="current"><?php echo $isbn ?></td>
                                                <td class="current"><?php echo $editore->return ?></td>
                                                <td class="current">
                                                    <?php
                                                        $prezzo=$client->leggiPrezzo(array('isbn'=>$isbn));
                                                        echo $prezzo->return; 
                                                    ?>
                                                </td>
                                                <td class="current"><?php echo '<a href="/libreria/'.$venditori->return[$i]->array[0].'">'.$venditori->return[$i]->array[0].'</a>'; ?></td>
                                                <td class="current"><?php echo $venditori->return[$i]->array[2] ?></td>
                                                <td class="current"><?php echo $venditori->return[$i]->array[1] ?>%</td>
                                            </tr><?php
                                        }
                                    }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- END CONTENUTO -->
             </div><?php
        }}?>
        <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href=""> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href=""> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
      	<!-- END FOOTER -->
    </div>       
    <?php
    echo '<pre>';
    var_dump($_SERVER);
    echo '</pre>';
    ?> 
</body>
</html>