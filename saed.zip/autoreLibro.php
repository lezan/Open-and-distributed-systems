<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Autore</title>
    <link rel="stylesheet" type="text/css" href="/libro.css" />
    <link rel="stylesheet" type="text/css" href="/footer.css" />
</head>

<body>
	<?php 
		session_start();
		function getUrl() {
 			return substr($_SERVER["QUERY_STRING"],strrpos($_SERVER["QUERY_STRING"],"=")+1);
		}
		$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
		$nomeAutore=getUrl();
		$nomeAutore=str_replace('%', ' ', $nomeAutore);
		$libriAutore=$client->ricercaAutore(array('campo'=>$nomeAutore)); ?>
        <div id="contenitoreGrande" class="page_settings_profile">
        	<?php
				if(isset($_SESSION['username'])) {?>
					<!-- START HEADER -->
					<div id="dashboard" class="headerLoggato">
						<ul>
							<li>
								<a href="/cerca.php" title="cerca">Cerca il libro</a>
							</li>
							<li id="dashboard_options"><?php
								echo '<strong>Ciao, '.$_SESSION['username'].'</strong>'; ?>
								|
								<a href="/logout.php" title="Esci"><span>Esci</span></a> 
							</li>
						</ul>
					</div>
					<div id="header2" class="headerLoggato">
						<div id="logo" class="">
							<span><a href="/index.php" title="Logo | Home">Logo</a></span> 
						</div>
						<div id="menus">
						<ul id="main_menu">
								<li id="tab_A">
									<a href="/index.php"><span>Pagina iniziale</span></a>
								</li>
								<li id="tab_B">
									<a href="/recensioniUtente.php"><span>La mia recensioni</span></a>
								</li>
								<li id="tab_C">
									<a href="/profiloUser.php"><span>Profilo</span></a>
								</li>
							</ul>
							</div>
					</div>
					<!-- END HEADER --><?php	
				}
				else if(isset($_SESSION['email'])) { ?>
					<!-- START HEADER -->
					<div id="dashboard" class="headerLoggato">
                    <ul>
                        <li>
                            <a href="/cerca.php" title="cerca">Cerca il libro</a>
                        </li>
                        <li id="dashboard_options"><?php
							$nomeLibreria=$client->leggiNomeLibreria(array('email'=>$_SESSION['email']));
                            echo '<strong>Ciao, '.$nomeLibreria->return.'</strong>'; ?>
                            |
                            <a href="/logout.php" title="Esci"><span>Esci</span></a> 
                        </li>
                    </ul>
                </div>
                <div id="header2" class="headerLoggato">
                    <div id="logo" class="">
                        <span><a href="/index.php" title="Logo | Home">Logo</a></span> 
                    </div>
                    <div id="menus">
                    <ul id="main_menu">
                            <li id="tab_A">
                                <a href="/index.php"><span>Pagina iniziale</span></a>
                            </li>
                            <li id="tab_B">
                                <a href="/libriLibreria.php"><span>I miei libri</span></a>
                            </li>
                            <li id="tab_C">
                                <a href="/profiloLibreria.php"><span>Profilo</span></a>
                           	</li>
                        </ul>
                     </div>
                </div>
					<!-- END HEADER --> <?php	
				}
				else { ?>
					<div id="header">
						<div id="header_logo">
							<a href="/index.php">La disoccupazione ci ha dato un bel mestiere;mestiere di merda CARABINIERE.</a>
						</div>
						<div id="login">
							<div id="botton_login">
								<a href="/login.php">Login</a>
								|
								<a href="/iscrizioneUser.php">Iscriviti</a>
								|
								<a href="/iscrizioneLibreria.php">Libreria</a>
							</div>
						</div>
						<div id="scritta">
							<h3 id="slogan">Anarchia.</h3>
						</div>
					</div> <?php	
				}
			?>        
        <!-- START CONTENUTO -->
        <div id="contenitorePiccolo">
            <div id="content">
            	<div id="titolo_content">
            		<h3><?php echo $nomeAutore ?></h3>
                    <h6>Qua sono visualizzate tutti i libri dell'autore <?php echo $nomeAutore ?> presenti nel nostro catalogo</h6>
            	</div>
                <?php
                	if($libriAutore->return=='') {
						echo '<div id="error">Non sono presenti libri per questo autore.<br /> Sei una libreria?! 
							<a href="/iscrizioneLireria.php">Iscriviti</a> e aggiungi questo autore al nostro catalogo.</div>';
					}
					else { ?>
                        <table> <?php
                            for($i=0;$i< count($libriAutore->return);$i++) { ?>
                                <tr>
                                    <td>
                                        <a id="cover_libro" href="#"><span>Cover</span></a>
                                    </td>
                                    <td>
                                        <ul>
                                            <li><span><span style="font-size:14px;">Titolo: </span><span style="font-style:italic;"><?php echo $libriAutore->return[$i]->array[0] ?></span></span></li>
                                            <li><span><span style="font-size:14px;">Autore: </span><span style="font-style:italic;"><?php echo $libriAutore->return[$i]->array[1] ?></span></span></li>
                                            <li><span><span style="font-size:14px;">Anno pubblicazione: </span><span style="font-style:italic;"><?php echo '<a href="/ricercaAvanzata.php?search_side_text='.$libriAutore->return[$i]->array[2].'&search_side_select=Anno&search_side_submit=Cerca">'.$libriAutore->return[$i]->array[2].'</a>'; ?></span></span></li>
                                            <li><span><span style="font-size:14px;">Editore: </span><span style="font-style:italic;"><?php echo '<a href="/ricercaAvanzata.php?search_side_text='.$libriAutore->return[$i]->array[3].'&search_side_select=Editore&search_side_submit=Cerca">'.$libriAutore->return[$i]->array[3].'</a>'; ?></span></span></li>
                                            <li><span><span style="font-size:14px;">ISBN: </span><span style="font-style:italic;"><?php echo '<a href="/books/'.$libriAutore->return[$i]->array[4].'">'.$libriAutore->return[$i]->array[4].'</a>'; ?></span></span></li>									
                                            <li><span><span style="font-size:14px;">Prezzo: </span><span style="font-style:italic;"><?php echo '<a href="/ricercaAvanzata.php?search_side_text='.$libriAutore->return[$i]->array[5].'&search_side_select=Prezzo&search_side_submit=Cerca">'.$libriAutore->return[$i]->array[5].'</a>'; ?></span></span></li>
                                            <li><span><span style="font-size:14px;">Lingua: </span><span style="font-style:italic;"><?php echo '<a href="/ricercaAvanzata.php?search_side_text='.$libriAutore->return[$i]->array[6].'&search_side_select=Lingua&search_side_submit=Cerca">'.$libriAutore->return[$i]->array[6].'</a>'; ?></span></span></li>
                                            <li><span><span style="font-size:14px;">Voto: </span><span style="font-style:italic;"><?php echo '<a href="/ricercaAvanzata.php?search_side_text='.$libriAutore->return[$i]->array[7].'&search_side_select=Voto&search_side_submit=Cerca">'.$libriAutore->return[$i]->array[7].'</a>'; ?></span></span></li>
                                        </ul>
                                    </td>
                                </tr> <?php
                            } ?>
                        </table> <?php
					}
				?>
            </div>
        </div>
        <!-- END CONTENUTO -->
        <!-- START FOOTER -->
        <div id="footer">
            <ul id="links_footer">
                <li class="item_footer">
                    <a href=""> Il nostro progetto</a>
                </li>
                <li class="item_footer">
                    <a href=""> Chi siamo?</a>
                </li>
                <li class="item_footer">
                    <a href="" class="last"> Contattaci</a>
                </li>
            </ul>
        </div>
      	<!-- END FOOTER -->
    </div>
</body>
</html>
