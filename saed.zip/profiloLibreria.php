<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento senza titolo</title>
    <link rel="stylesheet" type="text/css" href="profiloLibreria.css" />
</head>
<!-- Manca la funzione cin Java he faccia la modifica alla lista dei libri. Aggiungerla.
Ci sono da fare le stesse considerazioni fatte per profiloUser.php .
Bisogna fare in Java tutte le funzione che vanno a leggere i dati della libreria, e poi farlo mettere come value degli input.
Ma come lo facciamo? L'unica idea che mi viene in mente è mettere un text area supplementare(non editabile) che metta lì i dati attuali;
al di sotto l'input per inserire in nuovi dati. Che ne pensi? La stessa cosa è da fare per profiloUser.php, al limite. -->

<body>
	<?php
		session_start();
		if(!(isset($_SESSION['email']))) {
			header('Location:login.php');
		}
		else if (isset($_POST['modifica'])) {
			$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
		/*	$nomeLibreria=$client->leggiNomeLibreria($_SESSION['email']);*/
			/*$partitaIva=$client->leggiPartitaIva($_SESSION['email']);*/
			$parametri=array($_POST['password_old'],$_POST['password_new'],$_POST['email_libreria'],$_POST['nome_libreria'],$_POST['indirizzo_libreria'],$_POST['citta_libreria'],$_POST['cap_libreria'],$_POST['telefono_libreria'],$_POST['telefono2_libreria'],$_POST['partita_Iva'],$_SESSION['email']);
			$result=$client->editLibreria($parametri);
				if($result->return==0) {
					header('Location:/profiloLibreria.php?update=ok');
				}
				else if($result->return==6) {
					session_destroy();
					echo 'Email sostituita. Sei stato scollegato. Accedi con la nuova mail e la eventuale nuova password!';
					echo '<a href="/index.php">Torna alla pagina iniziale</a>';
				}
				else if($result->return==-1) {
					echo 'Errore generico';
					echo '<a href="/profiloLibreria.php"><br/>Torna al tuo profilo</a>';
				}
				else if($result->return==1) {
					echo 'Password nuova non corretta';
					echo '<a href="/profiloLibreria.php"><br/>Torna al tuo profilo</a>';
				}
				else if($result->return==2) {
					echo 'Password vecchia errata';
					echo '<a href="/profiloLibreria.php"><br/>Torna al tuo profilo</a>';
				}
				else if($result->return==3) {
					echo 'Partita Iva già utilizzata';
					echo '<a href="/profiloLibreria.php"><br/>Torna al tuo profilo</a>';
				}
				else if($result->return==4) {
					echo 'Nome già utilizzato';
					echo '<a href="/profiloLibreria.php"><br/>Torna al tuo profilo</a>';
				}
				else if($result->return==5) {
					echo 'Nuova email già utilizzata';
					echo '<a href="/profiloLibreria.php"><br/>Torna al tuo profilo</a>';
				}
		}
			else { ?>
                <div id="contenitoreGrande" class="page_settings_profile">
                    <!-- START HEADER -->
                    <div id="dashboard">
                        <ul>
                            <li>
                                <a href="cerca.php" title="cerca">Cerca il libro</a>
                            </li>
                            <li id="dashboard_options"><?php
                                echo '<strong>Ciao, '.$_SESSION['email'].'</strong>'; ?>
                                |
                                <a href="logout.php" title="Esci"><span>Esci</span></a> 
                            </li>
                        </ul>
                    </div>
                    <div id="header2">
                        <div id="logo" class="">
                            <span><a href="index.php" title="Logo | Home">Logo</a></span> 
                        </div>
                        <div id="menus">   
                            <ul id="main_menu">
                                <li id="tab_A">
                                    <a href="index.php"><span>Pagina iniziale</span></a>
                                </li>
                                <li id="tab_B">
                                    <a href="libriLibreria.php"><span>I miei libri</span></a>
                                </li>
                                <li id="tab_C">
                                    <a href="profiloLibreria.php"><span>Profilo</span></a>
                               </li>
                            </ul>
                        </div>
                    </div>
                    <!-- END HEADER -->
                    <!-- START CONTENUTO -->
			<?php
				if(isset($_GET['update'])){
					echo 'Dati aggiornati correttamente!<br/><br/>';
					unset($_GET['update']);
				}
				$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl');
				$parametri=array("email"=>$_SESSION['email']);
				$dati=$client->leggiDatiLibreria($parametri);
			?>
                    <div id="contenitorePiccolo">
                        <div id="content">
                            <div id="page_head">
                                <span>Modifica il tuo profilo</span>
                            </div>
                            <form id="change_profile" class="standard_form" action="profiloLibreria.php" method="post">
                                <h4>
                                    <label for="buddy_icon">
                                        <span>Il tuo avatar</span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Scegli un immagine per il tuo avatar</span>
                                </h6>
                                <div id="buddy_icon_wrap" class="input_wrap">
                                    <img src="icon_sample.gif" /> 
                                    <span class="options">
                                        <a href="modificaAvatar.php"><span>Modifica</span></a>
                                    </span>
                                </div>
                                <h4>
                                        <label for="password">
                                            <span>Password</span>
                                        </label>
                                    </h4>
                                    <div id="password_div" class="input_wrap">
                                        <h6>Inserisci la vecchia password</h6>
                                        <?php
                                            echo '<input type="password" id="password" class="text_input" name="password_old" size="30" min="8" maxlength="255" />';
                                        ?>
                                        <h6>Inserisci la nuova password</h6>
                                        <?php
                                            echo '<input type="password" id="password" class="text_input" name="password_new" size="30" maxlength="255" />';
                                        ?>
                                    </div>
                                <h4>
                                    <label for="nome_libreria">
                                        <span>Nome della libreria</span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Cambia il nome della libreria</span>
                                </h6>
                                <div id="nome_libreria_div" class="input_wrap">
                                    <?php
                                        echo '<input type="text" id="nome_libreria" class="text_input" name="nome_libreria" value="'.$dati->return['0'].'" size="30" maxlength="255" />';
                                    ?>
                                </div>
                                <h4>
                                    <label for="email_libreria">
                                        <span>Email</span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Cambia la tua email</span>
                                </h6>
                                <div id="email_libreria_div" class="input_wrap">
                                    <?php
                                        $emailLibreria=$_SESSION['email'];
                                        echo '<input type="text" id="email_libreria" class="text_input" name="email_libreria" value="'.$emailLibreria.'" size="30" maxlength="255" />';
                                    ?>
                                </div>
				<h4>
                                    <label for="partitaIva_libreria">
                                        <span>Partita Iva</span>
                                    </label>
                                </h4>
                                <h6 class="instruction">
                                    <span>Cambia la tua partita Iva</span>
                                </h6>
                                <div id="partitaIva_libreria_div" class="input_wrap">
                                    <?php
                                        echo '<input type="text" id="partita_Iva" class="text_input" name="partita_Iva" value="'.$dati->return['7'].'" size="30" maxlength="255" />';
                                    ?>
                                </div>
                                <div>
                                <h2>Indirizzo</h2>
                                <div id="indirizzo">                    	
                                    <h4>
                                        <label for="indirizzo_libreria">
                                            <span>Via/Pzza</span>
                                        </label>
                                    </h4>
                                    <h6 class="instruction">
                                        <span>Inserisci il tuo indirizzo</span>
                                    </h6>
                                    <div id="indirizzo_libreria_div" class="input_wrap">
                                        <?php
                                            echo '<input type="text" id="indirizzo_libreria" class="text_input" name="indirizzo_libreria" value="'.$dati->return['2'].'" size="30" maxlength="150" />';
                                        ?>
                                    </div>
                                    <h4>
                                        <label for="citta_libreria">
                                            <span>Citta</span>
                                        </label>
                                    </h4>
                                    <h6 class="instruction">
                                        <span>Inserisci la tua citta</span>
                                    </h6>
                                    <div id="citta_libreria_div" class="input_wrap">
                                        <?php
                                            echo '<input type="text" id="citta_libreria" class="text_input" name="citta_libreria" value="'.$dati->return['3'].'" size="30" maxlength="100" />';
                                        ?>
                                    </div>
                                    <h4>
                                        <label for="cap_libreria">
                                            <span>Cap</span>
                                        </label>
                                    </h4>
                                    <h6 class="instruction">
                                        <span>Inserisci il codice di avviamento postale</span>
                                    </h6>
                                    <div id="cap_libreria_div" class="input_wrap">
                                        <?php
                                            echo '<input type="text" id="cap_libreria" class="text_input" name="cap_libreria" value="'.$dati->return['4'].'" size="30" maxlength="5" />';
                                        ?>
                                    </div>
                                </div>
                                <h2>Telefoni</h2>
                                <div id="telefono">
                                    <h4>
                                        <label for="telefono_libreria">
                                            <span>Telefono</span>
                                        </label>
                                    </h4>
                                    <h6 class="instruction">
                                        <span>Inserisci un numero di telefono valido</span>
                                    </h6>
                                    <div id="telefono_libreria_div" class="input_wrap">
                                        <?php
                                            echo '<input type="text" id="telefono_libreria" class="text_input" name="telefono_libreria" value="'.$dati->return['5'].'" size="30" maxlength="10" />';
                                        ?>
                                    </div>
                                    <h4>
                                        <label for="telefono2_libreria">
                                            <span>Fax</span>
                                        </label>
                                    </h4>
                                    <h6 class="instruction">
                                        <span>Inserisci un numero di fax valido</span>
                                    </h6>
                                    <div id="telefono_libreria_div" class="input_wrap">
                                        <?php
                                            echo '<input type="text" id="telefono2_libreria" class="text_input" name="telefono2_libreria" value="'.$dati->return['6'].'" size="30" maxlength="10" />';
                                        ?>
                                    </div>
                                </div>
				<input type="hidden" name="modifica" value="modifica"/>
				<input type="hidden" name="updated" value="updated"/>
				<input type="submit" name="submit" value="Modifica profilo"/>
                            </form>
                    </div>
                    <!-- END CONTENUTO -->       
                    <!-- START FOOTER -->
                    <div id="footer">
                        <ul id="links_footer">
                            <li class="item_footer">
                                <a href=""> Il nostro progetto</a>
                            </li>
                            <li class="item_footer">
                                <a href="http://www.anobii.com/api_home"> Chi siamo?</a>
                            </li>
                            <li class="item_footer">
                                <a href="http://www.anobii.com/contact" class="last"> Contattaci</a>
                            </li>
                        </ul>
                    </div>
                    <!-- END FOOTER -->
                </div><?php
		}
	?>
</body>
</html>
