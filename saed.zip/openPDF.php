<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Leggi pdf</title>
</head>

<body>
	<?php /*
		//$file_path = $_SERVER['DOCUMENT_ROOT'].'/descrizione.pdf';
		$file_path = '/var/www/descrizione.pdf';
		header('Content-type: application/pdf');
		header('Content-Disposition: inline; filename=descrizione.pdf');
		readfile($file_path);
		if (file_exists($file_path)) {
			$file_info = pathinfo($file_path);
			$file_size = filesize($file_path);
			$file_name='descrizione.pdf';
			$file_extension = strtolower($file_info["extension"]);		 
			if($file_extension!='pdf') {
				echo '<div class="error">Estensione file non valida</div>';
				exit;
			}
			header('Content-type: application/pdf');
			header('Content-Disposition: attachment; filename="descrizione.pdf"');
			header('Content-length:'.$file_size);
			readfile($file_path);
		} else {
			echo '<div class="error">Il file non esiste</div>';
			exit;
		}*/
		$client= new SoapClient('http://localhost:8080/Libreria/services/Server?wsdl',array('features'=>SOAP_SINGLE_ELEMENT_ARRAYS));
		$result->leggiPDF();
	?>
</body>
</html>